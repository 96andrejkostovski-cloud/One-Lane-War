# Source-read contract, not an authorization to publish

Authority: One Lane War Design Lock v0.2.0; B001; T001. Verify MANIFEST.json first. Read source_authority.json and DESIGN_LOCK.md, then the canonical data registries. Ignore reference_history as implementation authority.

When the owner authorizes the first implementation task, begin with G1 only: install the selected editor/toolchain into the authorized environment, create the bounded two-scene Unity skeleton, import only selected packages, lock resolution, and prove an Android build on a verified ARM64-capable emulator. Record exact native dependencies/ABIs/page-size compatibility and failures. Do not spend, create live products, deploy a paid backend or publish.

No game-number TBDs: implement B001 literally. Do not add features, silently tune or swap dependency versions. A real incompatible dependency must be reported with evidence and resolved through a numbered toolchain amendment. Mechanical animation is locked; approved artwork is not present. Do not pretend placeholders are final.

Stop with an exact-head evidence packet and actual test/build results. G2, G3, assets, external services and release require the respective authorized task/gate.
