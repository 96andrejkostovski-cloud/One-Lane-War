#!/usr/bin/env python3
"""Source/math audit only. Does not simulate combat or run Unity/Android/SDKs.
Python3.10+, standard library. Run from any directory: python audit_lock.py
"""
from __future__ import annotations
import itertools, json, math, sys, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
checks=[]
def load(n):return json.loads((ROOT/'data'/f'{n}.json').read_text(encoding='utf-8'))
def check(name,condition,detail=''):
 checks.append({'name':name,'pass':bool(condition),'detail':detail})
def ceildiv(a,b):return (a+b-1)//b
def half(value,bp=10000):return (value*bp+5000)//10000
def bp(v):return int(round(v*10000))
def unit_stats(u,selected,rally):
 hp=damage=basebonus=rate=move=cost=0;dr=u['flat_damage_reduction']
 for a in selected:
  if a['requires_equipped_unit'] not in (None,u['id']):continue
  op=a['operator'];v=a['value'];extra=a['additional_rules']
  if op=='hp_add_pct':hp+=bp(v)
  elif op=='damage_add_pct':damage+=bp(v)
  elif op=='hp_and_damage_add_pct':hp+=bp(v);damage+=bp(v)
  elif op=='base_damage_add_pct':basebonus+=bp(v)
  elif op=='attack_rate_add_pct':rate+=bp(v)
  elif op=='move_speed_add_pct':move+=bp(v)
  elif op=='flat_reduction_add':dr+=v
  move+=bp(extra.get('movement_add_pct',0));cost+=bp(extra.get('supply_cost_add_pct',0))
 rate+=3000 if rally else 0
 ticks=max(7,ceildiv(u['attack_period_ticks']*10000,10000+rate))
 wind=min(ticks-1,max(1,ceildiv(u['windup_ticks']*10000,10000+rate)))
 return {'hp':half(u['hp'],10000+hp),'damage':half(u['damage'],10000+damage),
 'base_damage':half(u['base_damage'],10000+damage+basebonus),
 'cost':ceildiv(u['supply_cost']*(10000+cost),10000),'period_ticks':ticks,'windup_ticks':wind,
 'move_milli_s':min(2500,max(250,half(round(u['move_speed_m_s']*1000),10000+move))),'flat_reduction':dr}

def funding(e,units):
 bank=round(e['enemy_supply_start']*1000000);rate=round(e['enemy_supply_rate_per_s']*1000000)
 cap=round(e['enemy_supply_cap']*1000000);gap=round(e['enemy_min_deployment_gap_s']*20)
 nxt=round(e['enemy_first_deployment_earliest_s']*20);rem=0;idx=0;times=[]
 for t in range(3600):
  if t:
   gain,rem=divmod(rate+rem,20);bank=min(cap,bank+gain)
  if idx<len(e['enemy_spawn_queue']) and t>=nxt:
   c=units[e['enemy_spawn_queue'][idx]]['supply_cost']*1000000
   if bank>=c:bank-=c;times.append(t/20);idx+=1;nxt=t+gap
 return times

def economy_path(with_ads,units,encs,exps,econ):
 costs={**econ['troop_unlocks'],**{b['id']:b['cost_medals'] for b in econ['cosmetic_banners']}}
 order=econ['purchase_priority'];wallet=0;earned=0;owned=set();out=[];seen=set()
 for run in range(1,30):
  x=exps[min(run-1,len(exps)-1)];base=sum(encs[i]['win_medals'] for i in x['encounter_ids'])
  first=x['id'] not in seen;seen.add(x['id']);reward=base+x['completion_medals']+(x['first_clear_medals'] if first else 0)
  bonus=base//2 if with_ads and run>1 and len(owned)<len(order) else 0
  wallet+=reward+bonus;earned+=reward+bonus;new=[]
  for k in order:
   if k in owned:continue
   if wallet>=costs[k]:wallet-=costs[k];owned.add(k);new.append(k)
   else:break
  out.append({'clear_number':run,'expedition':x['id'],'base_and_completion':reward,'optional_bonus':bonus,'total_earned':earned,'wallet_after_purchases':wallet,'new_unlocks':new})
  if len(owned)==len(order):break
 return out

def main():
 try:
  files=list((ROOT/'data').glob('*.json'));data={f.stem:json.loads(f.read_text()) for f in files}
  check('All canonical JSON files parse',True,str(len(files)))
  U={u['id']:u for u in data['units']};UP={a['id']:a for a in data['upgrades']};E={e['id']:e for e in data['encounters']};A={a['id']:a for a in data['assets']};B={b['id']:b for b in data['boss_variants']}
  for name,expected in [('units',6),('upgrades',24),('encounters',36),('expeditions',9),('boss_variants',2),('products',2),('analytics_events',35),('assets',148),('qa_cases',93),('build_gates',11)]:
   rows=data[name];check(name+' count',len(rows)==expected,f'{len(rows)}/{expected}');check(name+' unique IDs',len({r['id'] for r in rows})==len(rows))
  rules=data['game_rules'];check('Lock is authorized, production is not',rules['design_lock_authorized'] and not rules['production_authorized'])
  check('Balance is not falsely described as playtested',rules['balance_status']=='LOCKED_DESIGN_NOT_GAMEPLAY_VALIDATED')
  check('No accounts/cloud/forced ads added',not rules['player_accounts'] and not rules['cloud_progression'] and rules['scope']['forced_ads']==0)
  for u in U.values():
   check(u['id']+' positive numeric values',all(u[k]>0 for k in ['hp','damage','base_damage','supply_cost','range_m','move_speed_m_s']))
   check(u['id']+' attack tick agreement',u['attack_period_ticks']==round(u['attack_period_s']*20) and u['windup_ticks']==round(u['windup_s']*20))
   check(u['id']+' tick ordering',0<u['windup_ticks']<u['attack_period_ticks'])
   check(u['id']+' asset',u['master_asset_id'] in A)
  check('Only four initial troops',sum(u['unlocked_initially'] for u in U.values())==4)
  check('Behavior/general counts',sum(a['kind']=='behavior' for a in UP.values())==6 and sum(a['requires_equipped_unit'] is None for a in UP.values())==6)
  for a in UP.values():
   check(a['id']+' references',a['icon_asset_id'] in A and a['requires_equipped_unit'] in [None,*U])
   check(a['id']+' one rank',a['max_rank']==1)
  seen=[]
  for x in data['expeditions']:
   ids=x['encounter_ids'];seen+=ids
   check(x['id']+' four assigned ordered encounters',len(ids)==4 and all(i in E for i in ids) and [E[i]['battle_index'] for i in ids]==[1,2,3,4] and all(E[i]['expedition_id']==x['id'] for i in ids))
  check('Every encounter assigned once',len(seen)==len(set(seen))==36)
  schedules=[]
  for e in E.values():
   q=e['enemy_spawn_queue'];check(e['id']+' finite valid queue',len(q)>0 and all(k in U for k in q) and e['policy']=='FINITE_ORDERED_QUEUE')
   check(e['id']+' exact spend',sum(U[k]['supply_cost'] for k in q)==e['enemy_total_supply_budget'])
   times=funding(e,U);check(e['id']+' funding feasible before180s without congestion',len(times)==len(q))
   check(e['id']+' stored funding bound',times and abs(times[-1]-e['minimum_funding_only_last_deployment_s'])<1e-9)
   if e['boss_variant']:
    b=B[e['boss_variant']];idx=e['boss_queue_index_zero_based'];check(e['id']+' boss index',0<=idx<len(q) and q[idx]==b['base_unit'] and e['battle_index']==4)
    check(e['id']+' boss can be revealed three seconds early',times[idx]>=e['boss_reveal_lead_s'])
   schedules.append({'encounter':e['id'],'deployments_s':times,'model':'funding/gap only; no combat or cap'})
  # Numeric audit over a superset of four-upgrade configurations; NOT battle simulations.
  sets=0;states=0;numeric_ok=True;minimum_pool=999;extremes={'max_hp':0,'max_base_hit':0,'minimum_period_ticks':999,'maximum_cost':0}
  for loadout in itertools.combinations(U,4):
   eligible=[a for a in UP.values() if a['requires_equipped_unit'] in [None,*loadout]]
   check('loadout '+'+'.join(loadout)+' eligibility',len(eligible)==18)
   minimum_pool=min(minimum_pool,len(eligible)-3)
   for chosen in itertools.combinations(eligible,4):
    sets+=1
    for uid in loadout:
     for rally in (False,True):
      s=unit_stats(U[uid],chosen,rally);states+=1
      numeric_ok &= s['hp']>0 and s['damage']>0 and s['base_damage']>0 and 0<s['windup_ticks']<s['period_ticks'] and 0<s['cost']<=200 and 250<=s['move_milli_s']<=2500
      extremes['max_hp']=max(extremes['max_hp'],s['hp']);extremes['max_base_hit']=max(extremes['max_base_hit'],s['base_damage']);extremes['minimum_period_ticks']=min(extremes['minimum_period_ticks'],s['period_ticks']);extremes['maximum_cost']=max(extremes['maximum_cost'],s['cost'])
  check('All four-upgrade numeric configuration sets',sets==45900,str(sets))
  check('Numeric unit/Rally state bounds',numeric_ok,str(states)+' states')
  check('Fourth draft cannot exhaust eligibility',minimum_pool>=3,str(minimum_pool))
  shield=UP['u04'];check('Barrier timer starts at damage not spawn',shield['additional_rules']['activation']=='first_positive_post_mitigation_damage' and shield['additional_rules']['absorbs_triggering_damage'])
  check('Ram base role stronger than equal-cost two crossbows',U['ram']['base_damage']/U['ram']['attack_period_s']>2*U['crossbowman']['base_damage']/U['crossbowman']['attack_period_s'])
  e=data['economy'];sinks=sum(e['troop_unlocks'].values())+sum(b['cost_medals'] for b in e['cosmetic_banners']);check('Finite sink total1320',sinks==1320)
  noads=economy_path(False,U,E,data['expeditions'],e);ads=economy_path(True,U,E,data['expeditions'],e)
  check('No-ad catalogue exhaustion at clear12',len(noads)==12)
  check('Maximum eligible bonus route catalogue exhaustion at clear10',len(ads)==10)
  check('Nine first clears pay990 before ads',noads[8]['total_earned']==990)
  milestones={k:r['clear_number'] for r in noads for k in r['new_unlocks']}
  check('No-ad purchase-priority milestones',milestones=={'brute':1,'ram':2,'banner_oak':4,'banner_barrel':7,'banner_iron':12},str(milestones))
  for a in data['animation_contract']['per_unit_timing']:
   check(a['unit_id']+' phases sum',abs(a['anticipation_release_s']+a['followthrough_s']+a['recovery_s']-a['attack_nominal_s'])<1e-8)
  for a in A.values():
   check(a['id']+' pending asset honesty',a['status']=='PLANNED_NOT_GENERATED' and a['source_path'] is None and a['sha256'] is None)
   check(a['id']+' dependencies',all(k in A for k in a.get('depends_on',[])))
  check('Game QA remains unexecuted',all(t['status']=='NOT_RUN' and t['evidence'] is None for t in data['qa_cases']))
  check('Twelve explicit closure QA fixtures',len(data['qa_lock_amendments'])==12)
  check('Closure QA has no fabricated results',all(t['status']=='NOT_RUN' and t['evidence'] is None for t in data['qa_lock_amendments']))
  check('105 planned game QA total',len(data['qa_cases'])+len(data['qa_lock_amendments'])==105)
  for key in ('menu','battle'):
   a=data['audio_vfx_contract']['music'][key];check(key+' music duration arithmetic',abs(a['bars']*4*60/a['bpm']-a['target_loop_s'])<1e-9)
  check('Sound family voice budget',data['audio_vfx_contract']['sfx']['per_family_voice_cap']<=data['audio_vfx_contract']['sfx']['max_simultaneous_voices'])
  check('G1–G10 evidence not fabricated',all(g['evidence'] is None for g in data['build_gates'] if g['id']!='G0'))
  check('IAP prices fixed',[(p['id'],p['usd_base_price']) for p in data['products']]==[('adfree_bonuses',4.99),('cosmetic_army_pack',2.99)])
  check('Toolchain selected not joint-build proven',data['toolchain_lock']['joint_compatibility_status']=='NOT_BUILT')
  check('No paid acquisition authorized',data['service_contract']['spending']['acquisition']==0)
  report={'scope':'STRUCTURE, NUMERIC COMBINATIONS, RESOURCE SCHEDULES, ECONOMY ONLY — NOT COMBAT/UNITY/DEVICE/SERVICE TESTS',
  'checks':len(checks),'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),
  'four_upgrade_configurations':sets,'unit_rally_numeric_states':states,'numeric_extremes':extremes,
  'funding_schedules':schedules,'economy_no_ads':noads,'economy_max_eligible_ads':ads,'check_results':checks,
  'not_run':['full combat simulation','Unity build','Android emulator','physical phone','real ads/billing/consent','real-player retention','asset visual approval']}
  (ROOT/'evidence'/'LOCK_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
  lines=['# Actual lock audit','',report['scope'],'',f"**{report['passed']}/{report['checks']} checks passed; {report['failed']} failed.**",'',f"Evaluated {sets:,} four-upgrade arithmetic configurations across15 loadouts, representing {states:,} unit/Rally numeric states. These are not battles.",'',f"Checked36 finite resource schedules without population/congestion/combat. No-ad route exhausts the1320-Medal catalogue after{len(noads)} full wins; maximum eligible-bonus route after{len(ads)}.",'','## Checks',*['- '+('PASS' if c['pass'] else 'FAIL')+' — '+c['name']+(' — '+c['detail'] if c['detail'] else '') for c in checks],'','## Not run',*['- '+n for n in report['not_run']]]
  (ROOT/'evidence'/'LOCK_AUDIT.md').write_text('\n'.join(lines)+'\n')
  print(json.dumps({k:report[k] for k in ['checks','passed','failed','four_upgrade_configurations','unit_rally_numeric_states','numeric_extremes']},indent=2))
  return int(report['failed']>0)
 except Exception as exc:
  print(f'Audit execution failed: {exc}',file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
