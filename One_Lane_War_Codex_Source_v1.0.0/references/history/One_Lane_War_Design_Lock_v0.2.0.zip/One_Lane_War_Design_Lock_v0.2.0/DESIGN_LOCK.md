# One Lane War — Design Lock v0.2.0

**27 September 2026 · Balance B001 · Toolchain T001 · UX001 · Analytics A001**

**Status: design locked under the owner’s explicit delegation.** These are the values to implement, not placeholders waiting for the owner to balance them. Whole-game playtest approval, exact artwork approval, a successful Unity build and publication are not claimed.

## 1. Authority and what this lock means

This package supersedes the numerical/configuration proposals in v0.1.0 and the intervening chat summaries. `source_authority.json` defines precedence. The JSON registries are the exact configuration authority. This manual defines the behavior around them. The old manual is retained under `reference_history/` solely to preserve history; it is not another live source.

The owner chooses visual execution later from comparable generated images. The Game Director owns balance, mechanics, toolchain selection, presentation timing and implementation requirements. Codex implements that source and reports evidence. Codex must not silently redesign counters, add permanent upgrades, substitute a different editor, or change prices because it prefers another result.

A design lock is not a promise never to correct an error. Corrections require a new numbered amendment with the reason, affected records, migration implications and regression evidence. Until amended, B001 is the numerical source of truth. There are no gameplay-stat questions left for the owner.

No external spending, generation batch, public repository mutation, signing, service deployment or store publication is performed or authorized by this package. These remain separately controlled execution actions.

## 2. Product boundary

Android/Google Play; Unity; landscape; comic medieval improvised equipment; no gore. One fixed-screen horizontal battlefield, both fortresses visible. Six troop types, four equipped, four battles per expedition, four upgrade selections, 24 upgrade definitions. Three chapters contain three expeditions each: 36 exact encounter records. Two bosses reuse existing units and effects. Three environments and six main UI views.

The intended audience is adults 18+, with an 18–44 strategy-player profile. This is a creative targeting decision, not legal proof or an IARC rating. Actual artwork, marketing and store declarations must agree. English-only launch, with string IDs. First production countries: US, UK, Canada, Australia, New Zealand and Ireland. Organic acquisition only.

Excluded: new ages, civilizations, factions, heroes, additional lanes, direct character control, PvP, multiplayer, leaderboards, guilds, quests, gear, loot boxes, pets, accounts, cloud saves, daily rewards, push notifications, energy, subscriptions, battle passes, permanent combat-stat levels, offline income, narrative sequences and remotely downloaded gameplay content. No new gameplay systems were added to close this design.

## 3. Player journey and complete lifecycle

First install loads local settings/save without waiting for advertising or analytics. Required consent precedes affected collection. The starter roster is Militia, Shieldguard, Crossbowman and Grenadier. The contextual tutorial teaches a frontline deployment, ranged support and Rally. It pauses for explanation, never deploys or pays on behalf of the player, and can be explicitly skipped. The first expedition attempt suppresses commercial offers even after tutorial skipping.

An expedition is Army/Briefing → Draft1 → Battle1 → reward checkpoint/Draft2 → Battle2 → Draft3 → Battle3 → Draft4 → stronghold Battle4 → Results. The army locks at the first draft. Supply, base health, units, Rally, counters and temporary effects reset each battle. Selected upgrades persist only during that expedition.

A battle win saves Medals exactly once. Battle4 also saves completion and first-clear rewards where applicable. Defeat or draw ends the expedition, retaining previously banked rewards. Starting again creates a new run ID at Battle1. Home between battles preserves a resumable run; starting another requires explicit abandonment. Force-close during battle restarts that same battle from the saved prebattle checkpoint, with identical choices and content version. No midbattle save promise and no restart reroll exploit.

The introductory battle targets45–90 seconds, normal battles90–150, strongholds120–180, and a whole expedition480–720 seconds including drafts. These are playtest targets, not measured durations or forced minimum timers.

## 4. Numerical combat authority

| Troop | Supply | HP | Troop hit | Base hit | Interval | Windup | Range | Move m/s | Reduction |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Militia | 20 | 70 | 11 | 11 | 0.8 s | 0.2 s | 0.6 m | 1.25 | 0 |
| Shieldguard | 45 | 240 | 10 | 10 | 1.1 s | 0.25 s | 0.65 m | 0.9 | 3 |
| Crossbowman | 50 | 75 | 50 | 25 | 1.8 s | 0.35 s | 5.5 m | 1.05 | 0 |
| Grenadier | 65 | 90 | 36 | 18 | 2.4 s | 0.5 s | 4.6 m | 0.95 | 0 |
| Brute | 110 | 480 | 65 | 65 | 1.6 s | 0.45 s | 0.85 m | 0.72 | 0 |
| Battering Ram | 100 | 420 | 14 | 150 | 2 s | 0.55 s | 0.85 m | 0.8 | 2 |


Player fortress HP is 900. The enemy fortress, bank, income and ordered troop queue are in each encounter. Base armor is 0; neither base attacks or heals. Player Supply starts 100, regenerates6/s and caps200. No kill income. One successful tap spends once and deploys; failure spends nothing and queues nothing. Global deployment delay is 0.30 s. Living limit 24 per side includes bonuses and bosses.

Rally grants30% additional attack rate for 5 s. It first becomes available12 s after battle start. Its30 s cooldown starts on activation. Affected attacks snapshot rate when they start; an ongoing attack is never retroactively accelerated. A unit deployed during Rally receives its bonus on new attacks. The enemy does not use Rally.

The simulation runs at 20 Hz. Coordinates/Supply use 1,000,000 integer units per world metre/Supply; percentage effects use basis points; intermediate arithmetic uses64-bit integers. HP/damage round positive halves up once after additive groups. Costs round up. Eligible damage has a minimum 1 after flat reduction. An attack period is `max(7,ceil(baseTicks*10000/(10000+rateBonusBp)))`. Windup uses the same speed scaling, bounded to1 through period−1 ticks. Remaining ticks are recovery. This closes differences between “20% faster” and “20% shorter interval.”

Normal damage modifiers affect both troop-hit and base-hit values, except Ram’s explicitly base-only upgrade. Damage, attack-rate, HP, movement and cost modifiers each sum in their own group; groups then apply to their relevant baseline. There are no crit/miss rolls. Movement is clamped0.25–2.5 m/s after modifiers. Division remainders carry between movement/income ticks so no low-rate drift accumulates.

Overtime begins at 150 s and doubles base damage for both sides without changing troop damage or income. Enemy orders expire at 180 s; existing troops/projectiles keep fighting. At210 s, after that tick’s committed damage, compare remaining base-health fractions by integer cross-multiplication. Exact tie and simultaneous fortress destruction are draws. No player-favoring hidden tie or loss rule.

## 5. Movement, target selection and damage timing

There is one logical lane28m long, base fronts0/28, spawn points0.8/27.2. Friendly formation uses three melee engagement positions per side, not selectable lanes. Living eligible incumbents keep positions; vacancies use nearest eligible melee then spawn ID. Reserves do not attack until a position becomes available. They move physically rather than teleporting. Groups have0.65m longitudinal separation. Protected ranged troops use0.45m queue spacing; melee may move past them. Render-only depth offsets make overlapping roles readable without changing targeting.

Opposing bodies cannot pass through one another. Range is edge-to-edge horizontal gap. A ranged unit without protection is a normal reachable target; it neither retreats automatically nor becomes immune because it is not melee. Target selection is nearest reachable enemy, stable spawn-ID tie-break. Multiple attackers may hit the same enemy; slots do not secretly force paired duels. Base targeting requires in-range base and no defending body in the path.

An attack snapshots modifiers/target/period at start. Melee rechecks the same target on impact; a dead or out-of-range target makes that strike miss, with recovery still spent. Crossbow projectiles ignore friendlies and hit the first intersected opposing body. Already released bolts survive shooter death. Swept movement detects intersections; no frame-rate tunneling. A bolt stops at its intended target position/path extent unless a selected pierce explicitly continues it.

A grenade commits to a ground X location when released, then lands after configured travel at 8 m/s. It damages enemies whose centres lie within its1m radius. It does not follow a target or damage friendly troops. A fortress receives grenade damage only when it was the valid direct target; splash may not bypass defenders. Crossbow projectile speed is 12 m/s.

Committed impacts due on the same death tick still resolve. Dead units start no future attack. Collect a tick’s damage before applying deaths so iteration order does not award a side a hidden advantage. Physics, animation events, particles and sound never award damage or Medals. Pause, backgrounding and service overlays freeze the simulation and its timers. Returning from background leaves battle paused until resumed.

## 6. Locked upgrades and interactions

| ID | Upgrade | Locked effect |
|---|---|---|
| U01 | Conscription | Every fifth paid Militia deployment grants one additional Militia. Bonus spawns do not increment this counter. |
| U02 | Scrap Blades | Militia damage +25%, including base damage. |
| U03 | Thick Coats | Militia maximum HP +25%. |
| U04 | First Into Battle | Shieldguard carries a barrier worth 30% of modified maximum HP. Its 8-second lifetime begins on the first positive incoming damage, absorbing that hit. One activation per unit. |
| U05 | Reinforced Shields | Shieldguard flat damage reduction increases by 2. |
| U06 | Heavy Boots | Shieldguard maximum HP +30%; movement speed -10%. |
| U07 | Piercing Bolts | A bolt may hit one additional enemy behind the first for 60% of the original bolt damage. |
| U08 | Tighter Windlass | Crossbowman damage +25%. |
| U09 | Quick Reload | Crossbowman attack rate +20%. |
| U10 | Packed Powder | Grenadier explosion radius +50%. |
| U11 | Heavy Charges | Grenadier damage +25%. |
| U12 | Fast Fuses | Grenadier attack rate +20%. Projectile travel is unchanged. |
| U13 | Sweeping Club | Brute strikes also hit the nearest two additional enemy units within 0.8m of the primary target for 40% damage. |
| U14 | Iron Belly | Brute maximum HP +25%. |
| U15 | Brutal Force | Brute damage +25%. |
| U16 | Splintering Head | Every third landed Ram hit on an enemy base deals an additional 100% of that hit’s direct damage to the base. |
| U17 | Siege Engineering | Ram base damage +35%; Supply cost +15%. |
| U18 | Reinforced Frame | Ram maximum HP +25%. |
| U19 | War Economy | Supply regeneration +15%. |
| U20 | Deep Stores | Supply capacity +50 and starting Supply +25 each battle. |
| U21 | War Drums | Rally duration +2 seconds. |
| U22 | Field Training | All troops gain +10% maximum HP and +10% damage. |
| U23 | Rapid Orders | Rally cooldown -5 seconds. The initial 12-second cooldown is unchanged. |
| U24 | Forced March | All troops move 15% faster. |


Every upgrade is single-rank and selectable once per expedition. All have equal base sampling weight. Four equipped units create18 eligible initial upgrades:12 troop-specific and 6 general. The first draft contains at least one eligible behavior upgrade. Later drafts contain at least one eligible troop upgrade and, while available, a general upgrade. Sample distinct offers without replacement; exclude already-selected upgrades. Offers may reappear on a later reroll unless chosen; this is explicit, not a hidden guarantee of three new alternatives.

Everyone has one free full-offer reroll per expedition. Exactly one further reroll is available through a rewarded ad or the permanent Ad-free entitlement. They are expedition-wide allowances, not per-draft. Save the offer, PRNG state and allowance transaction before displaying/consuming. Cancelled or failed ads do not consume an allowance.

Use XorShift32 with a nonzero32-bit run seed, unsigned wrap after shifts13/17/5, and rejection sampling for unbiased bounded picks. Save seed, current state, current offers and offer ordinal. Generate new-run seed once from platform cryptographic randomness; combat itself uses none. User input/clock changes do not reroll a displayed draft.

Conscription counts only successful paid Militia. Bonus troops cannot trigger it. At cap, keep one owed bonus; while owed, do not accumulate another. A new slot settles the owed troop before the next spawn phase’s paid command. Reset on next battle. Piercing secondary damage is 60% of the original pre-mitigation snapshot, rounded then mitigated independently; second target is within 1.5m behind the first; never a base. Brute’s additional hits select at most two other units within 0.8m,40% damage each, no base or recursive proc.

Ram counts landed direct base hits per Ram. Every third adds100% of that direct hit as separate nonrecursive base damage, with one victory settlement. Shield barriers are **armed at spawn but the8 s timer begins on the first positive incoming damage**; they absorb that triggering damage. The30% size uses modified max HP. No refresh. This prevents the defensive upgrade expiring during the approach march.

## 7. Encounter and boss authority

All36 complete queues are present in `encounters.json`; the table below summarizes them. The enemy is a finite deterministic purchase queue, not the adaptive “if the player has many units, buy Grenadier” example from earlier chat. It cannot inspect the player’s next purchase, revenue status, losses or advertisement decisions.

Enemy banking uses the same timer and cap principles, its own exact income,1.2 s minimum deployment gap, and no extra kill funds. The next queued unit waits until affordable and under cap. Never substitute, repeat the queue, grant a hidden refill or spend past its exact total budget. Orders unresolved at 180 s expire; they do not burst later. The player’s normal deployment remains available until battle resolution. This asymmetric defense schedule is visible in the rules, not an undisclosed adaptive advantage.

Twelve queues were shortened by removing unaffordable late tails, and budgets were recomputed. `evidence/QUEUE_AMENDMENTS.json` records every change. Funding-only scheduling is not a battle simulator: actual congestion can postpone or prevent units. All listed queues can be funded before the cutoff when cap/congestion does not interfere.

| Encounter | Doctrine | Enemy HP | Supply start / per s | Queue count / budget | Earliest last deployment* | Boss |
|---|---|---:|---:|---:|---:|---|
| c01_e01_b01 | militia_patrol | 650 | 70 / 4.5 | 8 / 215 | 32.25 s | — |
| c01_e01_b02 | shield_line | 650 | 70 / 4.5 | 16 / 650 | 128.90 s | — |
| c01_e01_b03 | swarm | 650 | 70 / 4.5 | 16 / 460 | 86.70 s | — |
| c01_e01_b04 | shield_line | 800 | 70 / 4.9 | 16 / 650 | 118.40 s | — |
| c01_e02_b01 | shield_line | 685 | 70 / 4.75 | 16 / 650 | 122.15 s | — |
| c01_e02_b02 | swarm | 685 | 70 / 4.75 | 16 / 460 | 82.15 s | — |
| c01_e02_b03 | artillery | 685 | 70 / 4.75 | 16 / 720 | 136.85 s | — |
| c01_e02_b04 | swarm | 835 | 70 / 5.15 | 16 / 460 | 75.75 s | — |
| c01_e03_b01 | swarm | 720 | 70 / 5.0 | 16 / 460 | 78.00 s | — |
| c01_e03_b02 | artillery | 720 | 70 / 5.0 | 16 / 720 | 130.00 s | — |
| c01_e03_b03 | shield_line | 720 | 70 / 5.0 | 16 / 650 | 116.00 s | — |
| c01_e03_b04 | artillery | 870 | 70 / 5.4 | 16 / 720 | 120.40 s | boss_bulwark |
| c02_e01_b01 | shield_line | 755 | 80 / 5.25 | 24 / 975 | 170.50 s | — |
| c02_e01_b02 | brute_guard | 755 | 80 / 5.25 | 21 / 995 | 174.30 s | — |
| c02_e01_b03 | swarm | 755 | 80 / 5.25 | 24 / 690 | 116.20 s | — |
| c02_e01_b04 | brute_guard | 905 | 80 / 5.65 | 22 / 1060 | 173.50 s | boss_bulwark |
| c02_e02_b01 | brute_guard | 790 | 80 / 5.5 | 22 / 1060 | 178.20 s | — |
| c02_e02_b02 | siege_push | 790 | 80 / 5.5 | 21 / 1050 | 176.40 s | — |
| c02_e02_b03 | artillery | 790 | 80 / 5.5 | 23 / 1030 | 172.75 s | — |
| c02_e02_b04 | siege_push | 940 | 80 / 5.9 | 23 / 1135 | 178.85 s | — |
| c02_e03_b01 | artillery | 825 | 80 / 5.75 | 24 / 1080 | 173.95 s | — |
| c02_e03_b02 | swarm | 825 | 80 / 5.75 | 24 / 690 | 106.10 s | — |
| c02_e03_b03 | brute_guard | 825 | 80 / 5.75 | 23 / 1105 | 178.30 s | — |
| c02_e03_b04 | artillery | 975 | 80 / 6.15 | 24 / 1080 | 162.65 s | boss_powder |
| c03_e01_b01 | mixed | 860 | 90 / 6.0 | 21 / 1110 | 170.00 s | — |
| c03_e01_b02 | shield_line | 860 | 90 / 6.0 | 24 / 975 | 147.50 s | — |
| c03_e01_b03 | siege_push | 860 | 90 / 6.0 | 23 / 1135 | 174.20 s | — |
| c03_e01_b04 | brute_guard | 1010 | 90 / 6.4 | 24 / 1125 | 161.75 s | boss_bulwark |
| c03_e02_b01 | siege_push | 895 | 90 / 6.25 | 24 / 1185 | 175.20 s | — |
| c03_e02_b02 | mixed | 895 | 90 / 6.25 | 21 / 1110 | 163.20 s | — |
| c03_e02_b03 | artillery | 895 | 90 / 6.25 | 24 / 1080 | 158.40 s | — |
| c03_e02_b04 | siege_push | 1045 | 90 / 6.65 | 24 / 1185 | 164.70 s | boss_powder |
| c03_e03_b01 | mixed | 930 | 90 / 6.5 | 22 / 1220 | 173.85 s | — |
| c03_e03_b02 | artillery | 930 | 90 / 6.5 | 24 / 1080 | 152.35 s | — |
| c03_e03_b03 | brute_guard | 930 | 90 / 6.5 | 24 / 1125 | 159.25 s | — |
| c03_e03_b04 | mixed | 1080 | 90 / 6.9 | 23 / 1265 | 170.30 s | boss_powder |


*This column is only an earliest resource/minimum-gap schedule with no deaths or population-cap model. It is not time-to-kill, predicted battle length or a claim all units will spawn in a live battle.*

Bulwark is a Shieldguard variant:480 HP,12 troop/base damage, normal period/movement/reduction and a144 HP first-damage barrier lasting8 s. Powder Captain is a Grenadier variant:158 HP,41 troop damage,21 base damage,1.5m splash, normal period/movement. Bosses use the base troop’s cost as a documented encounter exception. The exact replacement queue index is recorded, one boss maximum, disclosed at least 3 s before its earliest permitted deployment. No boss phases, new spells or special attack animations.

## 8. Economy and commercial terms

Medals are earned only. Unlock prices: Brute40, Ram80, Oak banner160, Barrel banner340, Iron banner700. Total catalogue cost1320. These replace the old banner120/180/240 values so progression does not exhaust substantially earlier than the selected pacing.

Each won battle pays 10/15/20 by chapter. Full expedition completion adds20/30/40. First clear adds20 once. A successful first-clear expedition therefore yields80/110/140. Replays yield60/90/120. Partial losses retain only previously won battle rewards.

Under the explicit no-ad route of completing all nine expeditions in order, then replaying the final expedition, and buying troops before banners: Brute is affordable after clear1; Ram after clear2; Oak after clear4; Barrel after clear7; all five purchases after clear12. The nine first clears pay 990, then three final-chapter replays pay 360, for 1350 total. This is a route calculation assuming full wins, not a guarantee for every player or purchase order. With every eligible Medal bonus and no failures, the same route finishes the catalogue after clear10. The first introductory attempt has no bonus.

Only two rewarded placements: one extra reroll, and 50% of that expedition’s banked battle-win Medals, rounded down, excluding completion/first-clear bonuses. The results bonus is allowed after a partial loss with at least one win. Each placement grants at most once per run. Hide the Medal placement once every earned unlock is owned, for purchasers and non-purchasers alike. Unused Medals may remain; no extra sink or permanent stat grind is added.

Ad-free Bonuses is a non-consumable with US base price$4.99. It changes eligible ad-backed actions into direct claims with identical limits. It is not unlimited rerolls or unlimited Medals. The Medal benefit is finite; disclose it. Cosmetic Army Pack is$2.99 for one coherent cosmetic set and no combat advantage. Localized prices come from Play. There are no forced ads, banners, purchased revives, recurring products or premium currency. These are locked initial prices, not validated conversion claims.

## 9. Animation mechanics; visual choice remains the owner’s

The mechanical method is fixed: separated transparent PNG parts, shared transform hierarchy for five humanoids, separate mechanical Ram, Unity-native AnimationClips/Animator, no root motion, no external skeletal software dependency. Source canvas1024×1024,512 pixels/world metre, feet-root convention. Art-specific pivots/joint lengths come from the selected drawings; they are not reasons to leave attack timing undecided.

| Troop | Move cycle | Attack | Release/impact | Follow-through | Recovery | Death |
|---|---:|---:|---:|---:|---:|---:|
| Militia | 0.64 s | 0.8 s | 0.2 s | 0.15 s | 0.45 s | 0.45 s |
| Shieldguard | 0.9 s | 1.1 s | 0.25 s | 0.2 s | 0.65 s | 0.6 s |
| Crossbowman | 0.8 s | 1.8 s | 0.35 s | 0.15 s | 1.3 s | 0.45 s |
| Grenadier | 0.85 s | 2.4 s | 0.5 s | 0.2 s | 1.7 s | 0.55 s |
| Brute | 1.1 s | 1.6 s | 0.45 s | 0.25 s | 0.9 s | 0.8 s |
| Battering Ram | distance-driven wheels | 2 s | 0.55 s | 0.3 s | 1.15 s | 1.0 s |


Idle loops2.4 s, victory loops1.6 s. Pose transitions blend0.08 s. Hit feedback is a0.10 s additive reaction without stun or reset. Death wins animation priority and begins when the model removes the unit; visual corpses never retain combat collision. Fade after the death clip is 0.25 s. Attack clips follow the quantized simulation snapshot; anticipation and recovery scale coherently with Rally. No simulation-wide hit pause. Ram wheel angle follows actual distance divided by0.25m wheel radius.

The future visual task produces three comparable treatments of the **same battlefield and controls**, not three different game designs. Owner selects the look. Then Militia, Crossbowman and Ram prove joints, motion, grip, both directions, projectile origins and crowded readability. Only after that approval is mass asset production allowed. This lock does not generate those images or claim a visual has been approved.

The existing148 asset-family records remain planned: six troops, two derived bosses, three environments, two bases, six portraits,36 animation bindings,24 upgrade icons, six main UI views,12 VFX families,25 SFX families, two music loops, three stings, earned/paid cosmetics and marketing assets. Preserve originals and provenance; repairs create revisions. Never bake live UI text/numbers into pictures.

Higgsfield supplies artwork, Suno music, ElevenLabs SFX, Unity assembles animation/VFX. Track actual provider/model, licence holder, applicable terms, generation/download dates, source and checksum. Having account access is not proof every generated output is commercially cleared. Music loops are edited for seamless playback; effects are dry and isolated. Use separate Music/SFX/UI mixer groups, pooled bounded voices/particles, audio focus recovery, optional haptics and reduced motion/flash. VFX exhaustion never discards simulation damage.

The production audio mix is also fixed in `audio_vfx_contract.json`: instrumental menu at 96 BPM/40 s and battle at 120 BPM/32 s, two 16-bar loops; victory/defeat/completion stings2/2/3 s;48kHz24-bit source masters; music target−16 LUFS and−1 dBTP. These are editing/mix targets, not a claim generated outputs automatically match them. Initial Music/SFX/UI levels are 0.55/0.80/0.65. Up to16 sound voices,3 of one family,64 active effects and 400 particles; reduce decorative work first. Final output still requires listening and on-device mix checks.

## 10. UI and save-state closure

`ui_contract.json` fixes functional screen regions, input behavior and state coverage; `strings_en.json` supplies English copy including templated amounts, purchase states, save failures and warnings. These are not final-look artwork. Six main views remain Home/Campaign, Army, Battle, Draft, Results and Shop, plus bounded overlays.

Use a1920×1080 reference canvas with safe-area anchors. Primary battle HUD112 reference pixels high, controls224 high, margins32. Four deployment controls sit in the lower strip with icon, Supply price and disabled reason. Rally is to their right; pause is top-right. A pointer-up in the pressed control commits one action; drag-out cancels. Minimum touch target48 dp, body text24 reference pixels. Test effective physical text size; the minimum reference values are not permission for unreadable scaled text.

Android Back closes the top dismissible overlay, otherwise pauses active battle, otherwise navigates toward Home. Never abandon silently. Store/consent overlays outrank confirmations and pause. Save/earned-reward commit failures block another conflicting purchase/claim until recovery rather than losing the first transaction.

Save schema1 uses a JSON envelope and corruption-detecting SHA256, active+backup copies, atomic replacement and versioned migrations. Checksums are not anti-cheat. Currency/unlock/grant/checkpoint changes commit together. A valid backup is used with an explanation. Unknown newer schema is never reset. Reset requires two confirmations, removes local gameplay but retains ownership and privacy/accessibility settings. Android backup/transfer exclusions reflect local-only progression; purchases restore separately. The loss risk is stated before destructive actions.

## 11. Toolchain T001

The exact selected editor is **Unity 6000.3.21f1**, changeset`c02631ffc030`. This is a documented LTS selection, not a claim to be the newest release. [T01]

| Component | Selected version/configuration |
|---|---|
| Unity editor |6000.3.21f1 LTS|
| Android min / compile / target |28 /36 /36|
| Release |IL2CPP, ARM64, OpenGLES3, built-in2D|
| Gradle / Android Gradle Plugin |9.1.0 /9.0.0|
| Android NDK |r27c,27.2.12479018|
| SDK build tools / platform tools |36.0.0 /36.0.0|
| SDK command-line tools |16.0|
| Java |OpenJDK17 bundled with that exact Unity editor|
| Input System / Newtonsoft |1.20.0 /3.2.2|
| uGUI / Test Framework |Editor-core copies bound to6000.3.21f1|
| Unity IAP / Services Core |5.4.3 /1.18.0|
| Native Play Billing |9.0.0|
| Firebase Unity / Android BoM |13.17.0 /34.19.0|
| Shared EDM4U resolver |1.2.189|
| Google Mobile Ads Unity / Android |11.5.0 /25.4.0|
| Android UMP |4.0.0|
| Android Studio |Quail4,2026.1.4 Patch1|
| Android Emulator |37.1.11|
| Entitlement backend |Firebase Functions2ndgen; managed nodejs22|
| Backend libraries |firebase-functions7.4.0; firebase-admin13.10.0|

Unity’s selected editor range determines its Gradle/AGP, NDK and SDK tools; do not combine the table for a later6000.3 patch with this editor. [T02,T03] Firebase 13.17.0 specifies C++13.13.0, Android BoM 34.19.0 and EDM4U 1.2.189. [T04] Ads plugin11.5.0 supplies the cited standard GMA/UMP dependencies. Next-generation ads and mediation are off. [T06–T08]

uGUI/Test Framework are core editor-matched packages, not an excuse to guess independent patch numbers. Use the bundled copies and commit the resolved lock. Likewise the editor-bundled JDK is the exact distribution choice; capture `java -version` and its binary hash at G1 rather than inventing an unverified JDK patch. [T11,T12] Provider-managed Node security patches are platform-controlled; record deployed revision and full npm lock, without pretending cloud service internals can be frozen permanently. [T15–T17]

Only Firebase App/Analytics/Crashlytics/Remote Config are imported. No Firebase AI/Auth/FCM/Firestore client module. Unity IAP is Google Play only; no D2C, webshop, remote catalogue or Unity Analytics. Its own Developer Data/telemetry settings still require explicit review, because disabling a separate Analytics package does not prove IAP sends no telemetry. [T05]

At G1 capture package locks, SDK hashes, editor changeset, resolved native dependencies, manifest, ABI inventory, JDK and system-image revisions. At G6 capture the backend lock/deployed revision. Selection is closed; **joint compatibility has not been built or proven here**. A conflict must become an evidenced, numbered T002 amendment, not an unrecorded “latest” update.

## 12. Services, privacy and failure states

The local game runs without backend, ads, analytics or Remote Config. The small backend exists only for purchase verification/ownership and refunds. Selected backend: Firebase second-generation functions, Node 22, ESM JavaScript, Firestore Native server-only, europe-west1. Initial per-function cap 2 instances, min0,256 MiB,1 CPU, concurrency10,30 s timeout,16KiB request limit. These control scale but are not guaranteed cash caps. No paid service is deployed by this document.

Validate Play package, product, purchase token, quantity and authoritative state before granting. A client installation ID is not ownership proof. Idempotent grant journal precedes acknowledgement. Pending payment grants nothing. Restore asks Play for actual ownership and verifies it; it cannot recover local campaign. RTDN is an authenticated server trigger and a reason to re-fetch authoritative state, not blind trust. Reconcile voided purchases separately. Cache server-signed ES256 ownership receipts for offline play and verify them using bundled public keys; a checksum alone is not purchase proof. Rotate signing keys without abandoning installed clients. Network failure never revokes a paid benefit. Log no raw tokens/order IDs in gameplay analytics. Restrict token access and database writes to the service identity.

Client network timeout15 s, retry delays1/4/15 s, then a recoverable manual retry. No background polling. Rewarded flow: eligibility → opt-in → load/show → earned callback → durable journal → grant once. Close is not an earned event. Duplicates and interrupted saves recover against the same receipt. If an extra-reroll earned receipt can no longer apply because its expedition ended, do not create a second run or reusable infinite reroll; preserve the receipt/reason for support. Such lifecycle behavior needs real SDK tests, not an assumption the callback survives every app kill.

UMP handles ad privacy; analytics/crash behavior is configured separately. Behavioral collection starts disabled and does not upload a pre-consent backlog. No precise location, birthday, names, email, raw tokens or free-text event fields. Initial behavioral export retention90days, support logs30days; statutory financial retention is determined from actual applicable requirements, not fabricated here. The final privacy policy/Data Safety must include every SDK including Unity IAP telemetry. Legal review and actual network verification are release evidence, not boxes made true by these selections.

Remote Config fetch no more than hourly, activate at Home/safe boundaries. Allowlist: ads, IAP, each of the two ad placements and support notice. Release service enablement starts false until owner-approved integration. No remote balance mutation in v1; no personalization or paid-player difficulty. Disabling offers must preserve already-owned benefits and earned rewards. An offline device cannot instantly receive a kill switch.

## 13. Analytics, acquisition and business rules

The35 custom event registry is retained. No per-hit telemetry. Aggregate battle spawns, damage, deaths, duration, peak population, Supply waste, Rally and outcome. Record upgrade offers/positions and selections, content version, environment, run/attempt IDs. Suppress duplicates and keep high-cardinality IDs out of summary dimensions. Do not manually re-emit automatic `first_open`, `ad_impression` or purchase events if the integration already supplies the canonical event.

Six dashboard pages: health, acquisition, retention, gameplay, monetization, cohort economics. `analytics_metrics.json` defines formula, denominator, maturity, sample and action. Internal targets:99.5% crash-free users; zero known save corruption or verified-purchase grant failures; earned-reward grant-failure alert at 0.5%;85% first-battle-start,80% tutorial completion/explicit skip (skip reported separately),50% first-expedition completion; D1/D7/D30 targets30/8/3%. These are project investigation thresholds, not industry standards or measured outcomes.

Cohort days use elapsed windows, not mixed calendar dates. D1 is 24–48h,D7 is 168–192h,D30 is 720–744h after first observed open. Foreground gameplay≥10 s qualifies; background SDK activity does not. Rate interpretation generally waits for 200 measurable mature installs, health rates500; always report denominators/uncertainty and consent missingness. A known critical defect blocks regardless of denominator. No immature D30 “pass,” no release held hostage to a nonexistent organic sample, and no conversion claims from friends testing.

Organic assets are five real gameplay concepts: swarm reversal, protected crossbows, grenade impact, Ram finish and visible upgrade transformation. Capture from attainable game state; no fake ad minigame, paid traffic, incentivized reviews or spam. Record source links where measurable. No promise of automatic downloads merely from a store listing.

Revenue reporting separates impression estimates, finalized ad earnings, gross IAP, refunds/fees/taxes/FX, net settlements, cloud/provider costs and founder time. Permanent purchases are not recurring subscriptions. End the Medal offer when its catalogue ends rather than inventing demand. Support cadence: health after releases, weekly gameplay/organic analysis, monthly close. This document schedules no automation or unseen background monitoring.

## 14. Testing and shipping

Android Studio emulator is the primary development environment. The matrix includes API 28/30/33/36 plus a16KB environment and multiple landscape sizes. API 30 is an explicit ARM64-translation fallback: Google documents ARM support in its Android11 x86_64 system images. That does not prove every newer/custom image or host supports the selected native libraries. [T10]

Unity 6.3 restricts its x86_64 target to existing Magic Leap projects; do not mislabel this new phone game as Magic Leap to create an emulator build. [T14] Use a verified ARM64-capable system image/translation path; record `ro.product.cpu.abilist`, image revision and actual native load. A failing or unsupported AVD row is BLOCKED, never PASS. API 28 ARM64 coverage may require a compatible host/image or physical device. This limitation does not reopen the user’s choice of emulator development; it prevents false native-test claims.

At least one actual ARM64 Android phone receives a Play-installed release smoke test. Emulation alone is not thermal/battery/touch/haptic proof. No new device purchase is authorized. Targets:60 fps primary,30 fps reduced rendering mode,20 Hz simulation unchanged,48 live troops,80 projectiles budget,500 MiB steady-state process memory and 150 MiB download target. Visual pool overflow cannot lose damage. Perform20-minute soak, background/resume, storage-full, low/no network, audio focus, safe area and settings tests.

There are 93 inherited game QA cases, all still NOT_RUN. Add fixtures for this lock’s barrier timing, base damage, queue cutoff/boss index, number quantization,reward-total and 1320-cost consistency and restore/consent state handling. The source audit tests only files/math, not these Unity/SDK scenarios.

G0 design lock → G1 toolchain proof → G2 chosen look/three-unit motion → G3 one-shot complete core expedition with explicit service stubs → G4 exact-head review/correction → G5 full bounded content and combat testing; G6 real services can follow G4 in parallel → G7 release candidate → G8 independent closed validation → G9 owner publication → G10 operations. No gate silently advances because a document exists. G0 does not claim G1 or visual proof passed.

Use a dedicated repository when authorized, protected main, version/hash in every task, no secrets in Git, locally repeatable builds and an exact-head evidence packet. Report actual test commands/counts, logs, screenshots and artifact hashes. Review the final commit rather than an earlier passing commit. Record the first one-shot attempt honestly; later corrections are later corrections.

Shipping: debug/local → Play internal → closed testing → owner-approved first production in six countries. Produce an AAB, signing/upload-key protection, symbol upload, release manifest, real store-installed smoke test, purchase/restore/refund tests, ad readiness, app-ads.txt, privacy/support URLs, truthful screenshots/copy, audience/IARC declarations and SDK/data inventory. API 36 target is selected; recheck changing store requirements at submission rather than assuming today’s pin authorizes a future submission. First production country exposure differs from percentage-staged updates; no fictitious5% first-release rollout. Subsequent updates may stage and use fix-forward versions, not promise in-place binary downgrade.

Public title/package ID, actual verified publisher entity, domain/email, credential ownership and store identifiers are deployment inputs. No dummy values may reach production. Internal codename and C# namespace are OneLaneWar; final commercial naming is not fabricated as legal clearance. Existing purchases must survive temporary outages and responsible retirement; disable new sales before withdrawing service. Back up source, rights evidence, accepted assets, symbols, release files and entitlement records independently and test restoration.

## 15. Closure and evidence status

**Closed:** product scope, numerical B001, all 36 enemy policies,24 upgrades, economy/prices, animation mechanics, functional UI/copy, selected T001, service defaults, analytics formulas, test matrix and gate order.

**Intentionally not asserted:** a chosen visual reference, generated art/audio, successful Unity build, validated combat win rates, real-device results, verified rights for future outputs, store-account completion, deployment, publication or commercial success.

The actual reproducible source/math audit is in `evidence/LOCK_AUDIT.json` and `evidence/LOCK_AUDIT.md`. It is not a gameplay validation report. No unresolved gameplay number is handed back to the owner.

## Source index for toolchain facts

- [T01] Unity 6000.3.21f1 release: https://unity.com/releases/editor/whats-new/6000.3.21f1 (checked27 September2026).
- [T02] Unity Android dependencies: https://docs.unity3d.com/6000.3/Documentation/Manual/android-supported-dependency-versions.html (checked27 September2026).
- [T03] Unity Gradle compatibility: https://docs.unity3d.com/6000.3/Documentation/Manual/android-gradle-version-compatibility.html (checked27 September2026).
- [T04] Firebase Unity releases: https://firebase.google.com/support/release-notes/unity (checked27 September2026).
- [T05] Unity IAP5.4 changelog: https://docs.unity3d.com/Packages/com.unity.purchasing@5.4/changelog/CHANGELOG.html (checked27 September2026).
- [T06] Mobile Ads Unity releases: https://github.com/googleads/googleads-mobile-unity/releases (checked27 September2026).
- [T07] Ads11.5 native dependencies: https://raw.githubusercontent.com/googleads/googleads-mobile-unity/v11.5.0/source/plugin/Assets/GoogleMobileAds/Editor/GoogleMobileAdsDependencies.xml (checked27 September2026).
- [T08] Ads11.5 UMP dependency: https://raw.githubusercontent.com/googleads/googleads-mobile-unity/v11.5.0/source/plugin/Assets/GoogleMobileAds/Editor/GoogleUmpDependencies.xml (checked27 September2026).
- [T09] Android Studio updates: https://developer.android.com/latest-updates (checked27 September2026).
- [T10] Android Emulator releases and ARM translation: https://developer.android.com/studio/releases/emulator (checked27 September2026).
- [T11] Unity core uGUI binding: https://docs.unity3d.com/6000.3/Documentation/Manual/com.unity.ugui.html (checked27 September2026).
- [T12] Unity core test framework binding: https://docs.unity3d.com/6000.3/Documentation/Manual/com.unity.test-framework.html (checked27 September2026).
- [T13] Unity Newtonsoft package3.2.2: https://docs.unity3d.com/Packages/com.unity.nuget.newtonsoft-json@3.2/manual/index.html (checked27 September2026).
- [T14] Unity Android x86_64 restriction: https://docs.unity3d.com/6000.3/Documentation/ScriptReference/AndroidArchitecture.X86_64.html (checked27 September2026).
- [T15] Functions runtime options: https://firebase.google.com/docs/functions/manage-functions (checked27 September2026).
- [T16] Firebase Functions releases: https://github.com/firebase/firebase-functions/releases (checked27 September2026).
- [T17] Firebase Admin releases: https://github.com/firebase/firebase-admin-node/releases (checked27 September2026).

Provider/platform references retained in `data/sources.json` support the unchanged release obligations from the original planning document; revalidate them at actual submission. Original game-design values and policies in this manual are decisions, not external facts.
