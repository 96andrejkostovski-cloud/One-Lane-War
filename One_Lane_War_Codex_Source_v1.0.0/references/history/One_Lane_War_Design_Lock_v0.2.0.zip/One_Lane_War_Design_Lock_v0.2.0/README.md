# One Lane War — Design Lock v0.2.0

Open DESIGN_LOCK.html or DESIGN_LOCK.md. Source authority is source_authority.json, then data/*.json, then DESIGN_LOCK.md. Historical v0.1.0 is NOT active.

This is a real versioned design/configuration package, not a Unity project or Android build. B001/T001/UX001/A001 are selected. Visual execution remains owner-selected. No spending, external mutation or publication performed.

Run `python audit_lock.py` for the source/math audit (Python3.10+, standard library). Read evidence/LOCK_AUDIT.md for limits and results. No Unity playtest, native build or services test is reported as passed.
