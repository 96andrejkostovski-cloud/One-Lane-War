# Codex intake — planning only

Read `README.md`, `MASTER_PLAN.md`, `data/open_decisions.json`, then `data/build_gates.json`. Run `python validate_plan.py` and report genuine structural findings.

**This package does not authorize an implementation, repository mutation, asset generation, provider spending, service deployment, store configuration, merge or publication.** Do not mark G0 complete merely because the validator passes. The owner must explicitly approve a frozen source and authorize a task.

For a later authorized build task, receive: source version and hash; exact repository/base HEAD; gate/task ID; allowed and excluded changes; required acceptance tests; evidence paths; output expectations; and stop conditions. Implement only that task. Record follow-up fixes honestly rather than calling a multi-iteration build a one-shot success.

Never insert dummy credentials, fabricate device results, overwrite an approved asset, hide a failing test, or convert a pending service into an always-successful fake in a production build. Unknown numerical values remain candidates until verified through the specified proof gate. Human visual and publishing approvals remain human.
