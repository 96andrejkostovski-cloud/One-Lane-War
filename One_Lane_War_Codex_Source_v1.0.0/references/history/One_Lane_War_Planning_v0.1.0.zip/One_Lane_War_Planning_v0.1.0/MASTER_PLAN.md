# One Lane War — Complete Planning Baseline

**Version:** 0.1.0 · **Prepared:** 27 September 2026  
**Status:** PROPOSED — not human-approved, source-frozen, production-authorized, balance-validated, or release-approved.

This is a bounded design and production specification for the fourth, deliberately small game alongside Roman Legacy, Bad Boots Good Loot, and Reactorfall. It is not a Unity implementation. Numerical gameplay values are starting configurations to test, not measured outcomes. Provider and platform facts are sourced at the end and were checked on 27 September 2026. Recheck changing rules when the toolchain is pinned and before submission.

The user specified Unity, Higgsfield visuals, and audio providers interpreted as Suno for music and ElevenLabs for sound effects. This plan preserves those choices. It expands existing mechanics and production obligations; it does not authorize additional gameplay systems or spending.

## 1. Product boundary and commercial thesis

**Promise:** choose four troops, assemble a combination through four battles, and break an enemy fortress through deployment timing rather than direct character control.

The intended audience is people who enjoy readable, short single-player strategy sessions. The proposed presentation is mildly comic medieval warfare with improvised equipment, no blood, and no real-world military branding. Audience declarations must reflect the finished product and its marketing; an adult-targeted label cannot be used merely to avoid children’s requirements.

Landscape, one fixed battlefield, six troops, 24 upgrade definitions, three chapters, nine expeditions, 36 encounter configurations, two derived boss variants, three background themes, one earned persistent currency, two rewarded placements, two permanent purchases. The six main views are Home/Campaign, Army, Battle, Draft, Results, and Shop. Settings, pause, consent, briefing, and error states are overlays, not more gameplay modes.

Excluded: multiplayer, PvP, guilds, login accounts, cross-device saves, inventories, equipment, factions, extra lanes, premium currency, gacha, purchased revives, subscriptions, battle passes, daily quests, energy, push notifications, live A/B tests, downloadable content, voice acting, and narrative cinematics. No forced advertisements of any format. No requirement to pay or watch an ad to complete the campaign.

**Revenue thesis:** a replayable tactical toy may earn from optional bonuses and permanent convenience/cosmetics. This is a hypothesis. The finite catalogue limits both long-term progression and Medal-ad demand. It is not reasonable to assume indefinite retention, high cosmetic sales, or profitable paid acquisition.

**Definition of scope discipline:** fixes to a confusing decision, bad attack timing, asset inconsistency, broken purchase, or unreliable save are required production work. Adding a seventh troop or a new progression system is not a fix within this baseline.

## 2. Player journey and exact run structure

### First launch

Startup loads local configuration, settings, and the latest valid save before any network-dependent operation. It checks service availability without blocking offline play. Required legal/consent UI appears before affected data collection or ad requests. No store popup or advertisement appears during the introductory expedition attempt.

The player starts with Militia, Shieldguard, Crossbowman, and Grenadier. There are already four meaningful buttons, not a lengthy two-button grind. The first entry uses those four as the loadout; later entries open Army as needed. No player name, email, account, or birthday is collected by default. Any age treatment required by the final audience/legal configuration must be resolved before service integration.

The tutorial is three contextual steps: deploy a Shieldguard; deploy a Crossbowman behind it; use Rally after the first engagement. Brief prompts pause the simulation and do not buy units or activate Rally for the player. Instructions can be dismissed; completion flags are saved. The first encounter has a gentler fixed opening, not hidden damage immunity or an unwinnable staged defeat. The tutorial is part of encounter c01_e01_b01, not a separate campaign or scene.

### Expedition lifecycle

Home/Campaign → Army/briefing → starting Draft → Battle 1 → reward summary/Draft → Battle 2 → reward summary/Draft → Battle 3 → reward summary/Draft → stronghold Battle 4 → Results → Home.

There is one upgrade before each battle: four choices in total. Chosen upgrades remain until the expedition ends. Unit health, units on the field, Supply, Rally, deployment counters, and temporary effects reset between battles. Base health resets to that encounter’s configured starting value. The loadout locks after the initial draft; no changing units to make already-chosen upgrades retroactively useful.

A normal battle targets 90–150 seconds and the final battle 120–180 seconds. An expedition targets roughly 8–12 minutes including choices, not a guaranteed duration. The runtime has explicit overtime and a hard finish; it must not stall forever.

### Success, failure, retry, and quitting

Each won battle grants its Medals once, immediately in an atomic checkpoint. Completing Battle 4 also grants the expedition completion bonus and, where applicable, its one-time first-clear bonus. Losing or drawing ends the expedition. Previously won battle rewards remain. The unresolved battle grants nothing. Retry begins a new expedition, with a new run ID, starting at Battle 1.

Pause → abandon requires a confirmation stating exactly which banked rewards remain. Returning to Home between battles preserves the checkpoint; Home displays Resume rather than silently starting a different run. Starting another expedition while one is active requires explicit abandonment.

Killing the app during a battle restarts that battle from its saved prebattle state: same encounter, loadout, upgrades, content version, and enemy plan. No partial battle reward, no rewind of already-banked rewards, no new upgrade choices. This simpler policy is intentional; there is no promise of exact mid-battle cloud or device recovery.

## 3. Combat contract

### Space, clocks, and authority

One logical horizontal lane is 28 world metres long. Base fronts are x=0 and x=28; spawn points are 0.8 and 27.2. The camera shows both bases and all traversable space. Presentation may use small depth offsets to separate silhouettes; those offsets never create independently selectable lanes or change range.

The simulation runs at 20 fixed steps per second with presentation interpolation. Use integer ticks, integer HP/damage, and a documented fixed-point representation for movement/Supply. Randomness is limited to seeded draft selection; combat has no hidden hit/miss/critical rolls. Physics contacts and animation events never award damage or currency.

Within a tick: validate queued player commands; update resources and enemy deployment; assign movement/engagement targets; move units; advance attacks/projectiles; collect damage events; resolve simultaneous damage; remove deaths; resolve base outcomes; then publish presentation/analytics summaries. Stable IDs break ties. A unit killed by damage in the same tick as its already-due impact still contributes that impact; a dead unit cannot begin a new attack next tick.

Pause, backgrounding, or SDK overlays stop the gameplay clock. Supply, Rally cooldown, and enemy purchases do not advance while paused. Returning from the background shows a paused battle until the player resumes, avoiding an unexpected immediate attack.

### Supply and deployment

Player starting Supply is 100, regeneration 6 per second, capacity 200. There is no kill income, manual collection, paid refill, or offline production. Supply stops accumulating at the cap; wasted regeneration is measurable.

One completed tap attempts one deployment. A 0.3-second global deployment cooldown prevents accidental multi-touch bursts. Held fingers do not repeatedly deploy. Button press validates the equipped unit, active battle, sufficient funds, cooldown, and alive-unit cap before spending. Failure spends nothing, creates no queue, and displays a reason. A successful deployment deducts cost and creates the unit in the same simulation transaction.

The cap is 24 living units per side, including bonus Militia and bosses. A full army never consumes Supply for an unspawned unit. UI shows army capacity when relevant; no new persistent resource is introduced.

### Frontline, spacing, and engagement

The solver uses one shared frontline with at most three melee engagement slots per side. These are formation positions, not separate combat lanes. Melee applicants are ordered by proximity to the nearest opposing frontage, then spawn ID; alive incumbents retain their slots while eligible. Reserves queue behind them in groups of three. Their desired positions are separated longitudinally by 0.65m; rendering uses a small deterministic depth offset inside each group.

A slot reservation does not teleport a unit into attack range. The unit moves toward the position at its configured speed and can attack only after satisfying actual range. The slot is freed when its owner dies or leaves the engagement. Larger units still occupy one slot; their attack/range and visual footprint are configured separately.

Ranged units do not occupy melee slots while protected by friendly melee. Friendly melee may advance past friendly ranged units. Ranged units stop when their attack range is satisfied and use minimum visual spacing of 0.45m within their ranged queue. When no melee protects a ranged unit, it becomes a reachable frontline target; it does not retreat, kite, or create an invulnerable firing line.

Opposing units cannot pass through one another. Movement is clamped at the opposing frontage using half-widths. Friendly movement is formation-controlled rather than Rigidbody collision-driven. Target selection is closest reachable opposing unit by x-distance, then stable ID. A unit attacks a base only when in base range and no opposing unit blocks the attack path. This prevents Rams and ranged units firing through a defending army to hit the fortress.

This solver is a particularly important proof gate. Tests must cover empty lanes, only ranged armies, melee catching ranged troops, new reinforcements, simultaneous deaths, asymmetric speeds, and three-slot turnover. If the proposed formation rule produces unreadable or uninteresting fighting, revise this rule and its tests through a versioned source amendment before full-content production; do not patch around it with undocumented exceptions.

### Attacks, projectiles, and damage

A unit begins an attack only with a valid in-range target. Attack start snapshots its damage modifiers, attack period, and target. Windup and recovery are based on that attack period. Rally changes newly-started attacks; it does not retroactively shorten an attack already in progress.

For melee, recheck the target at the impact tick. If dead or no longer in range, the strike misses and still completes its recovery. Do not snap the hit to another target. For Crossbowman, create a simulation projectile at release; it travels toward the target’s launch-time x-position and hits the first opposing unit intersected along its path, or the intended base when eligible. It ignores friendly bodies. A dead shooter does not erase an already-released bolt. Each projectile records target IDs already hit to prevent double damage.

A Grenadier lob records a ground x-position at release and explodes there after travel. Splash damages opposing units with centres inside the configured one-dimensional radius; no friendly fire. A base is a separate target: only a grenade whose direct target was that base can damage it. Splash cannot bypass defenders by clipping a fortress behind them.

Damage calculation: calculate the attacker’s appropriate troop/base damage with additive percentage modifiers; round once to the nearest integer, half up; apply overtime base multiplier if applicable; subtract target flat reduction with minimum 1 damage; absorb from any active barrier; deduct remaining HP. Barrier loss does not also reduce HP. No damage type, resistance table, critical chance, armor penetration, lifesteal, or recursive proc system exists.

Maximum HP modifiers add together within their group. Attack-rate modifiers add together; period = base period / (1 + total rate bonus). Starting safety bounds: attack period at least 0.35s, movement between 0.25 and 2.5m/s, base reduction cannot lower an impact below 1. Cost is rounded up after percentage modifiers. All gameplay calculations use the same functions for player, enemy, UI, and test tools.

### Rally

Rally gives +30% attack rate for 5 seconds to living friendly troops and troops deployed while it remains active. Its cooldown is 30 seconds from activation; the initial cooldown is 12 seconds. It grants no Supply, damage immunity, direct damage, or healing. Only the existing Rally upgrades modify it. Death animations and frozen background time do not consume active duration.

### Bases and battle termination

Bases do not have turrets, passive attack, healing, or manual repair. Fortresses have readable health bars, a hit reaction, damage-state visuals, and destruction feedback. Player starting HP is 900 in the initial registry; enemy HP varies explicitly by encounter.

At 150 seconds, show Overtime and double damage dealt to bases by both sides; troop damage and Supply remain unchanged. At 210 seconds, compare remaining base-health fractions using integer cross-multiplication. Higher fraction wins; exact equality is DRAW. If both bases are destroyed in the same tick, DRAW. A draw ends the expedition, awards no unresolved-battle reward, and retains previously banked Medals. No coin flip or invisible player disadvantage resolves ties.

## 4. Troops and balance scope

The JSON unit registry is the numeric source. The starting values below are not balanced through simulation yet.

| Troop | Supply | HP | Damage/attack | Period | Range | Movement | Special baseline |
|---|---:|---:|---:|---:|---:|---:|---|
| Militia | 20 | 70 | 11 | 0.8s | 0.6m | 1.25m/s | Cheap reserves |
| Shieldguard | 45 | 240 | 10 | 1.1s | 0.65m | 0.9m/s | Flat reduction 3 |
| Crossbowman | 50 | 75 | 50 | 1.8s | 5.5m | 1.05m/s | Bolt projectile |
| Grenadier | 65 | 90 | 36 | 2.4s | 4.6m | 0.95m/s | 1m splash radius |
| Brute | 110 | 480 | 65 | 1.6s | 0.85m | 0.72m/s | Large slow melee |
| Ram | 100 | 420 | 14 vs troops / 110 vs base | 2s | 0.85m | 0.65m/s | Flat reduction 2 |

Counter relationships are hypotheses to prove using equal Supply budgets and the actual formation rules. Militia should punish slow overkill attacks through replacement bodies; Grenadiers should punish concentrated queues; Crossbowmen should threaten durable units when protected; Shieldguards should buy time against repeated light hits; Rams should turn a winning frontage into a finish. No unit gains a counter merely because its description says so.

All 15 four-unit loadouts must be able to finish appropriate campaign content under reasonable draft outcomes and skilled deployment. They need not have identical difficulty or win rates. A Ram-free lineup must still be able to destroy bases. A Grenadier-free lineup must still have a feasible response to swarms. The starter four must not hit a mandatory unlock/paywall.

Two bosses reuse existing troop bases and mechanics. Bulwark is a larger Shieldguard with higher HP/damage and the existing temporary barrier effect. Powder Captain is a larger Grenadier with higher HP/damage and the existing radius effect. Each appears at most once in its configured encounter and is disclosed in the briefing. There are no new boss phases, cinematics, animations, or spell systems. Their stronger stats are an explicit encounter-budget exception, not hidden AI cheating.

## 5. The complete 24-upgrade catalogue

Every upgrade has one rank, can be selected at most once per expedition, and uses equal base selection weight. Eighteen apply to individual troops and six are general. A troop-specific upgrade is eligible only when that troop is equipped.

| ID | Upgrade | Exact initial effect |
|---|---|---|
| U01 | Conscription | Every fifth paid Militia deployment grants one additional Militia |
| U02 | Scrap Blades | Militia damage +25% |
| U03 | Thick Coats | Militia maximum HP +25% |
| U04 | First Into Battle | Shieldguard spawns with 30%-max-HP barrier lasting 8 seconds |
| U05 | Reinforced Shields | Shieldguard flat reduction +2 |
| U06 | Heavy Boots | Shieldguard HP +30%; movement -10% |
| U07 | Piercing Bolts | Bolt hits one extra enemy behind first for 60% original damage |
| U08 | Tighter Windlass | Crossbowman damage +25% |
| U09 | Quick Reload | Crossbowman attack rate +20% |
| U10 | Packed Powder | Grenadier radius +50% |
| U11 | Heavy Charges | Grenadier damage +25% |
| U12 | Fast Fuses | Grenadier attack rate +20%; travel unchanged |
| U13 | Sweeping Club | Brute hits nearest two additional units within 0.8m of primary for 40% damage |
| U14 | Iron Belly | Brute maximum HP +25% |
| U15 | Brutal Force | Brute damage +25% |
| U16 | Splintering Head | Every third landed Ram base hit adds 100% direct-hit damage to that base |
| U17 | Siege Engineering | Ram base damage +35%; cost +15% |
| U18 | Reinforced Frame | Ram maximum HP +25% |
| U19 | War Economy | Supply regeneration +15% |
| U20 | Deep Stores | Supply capacity +50; starting Supply +25 |
| U21 | War Drums | Rally duration +2 seconds |
| U22 | Field Training | All troops HP +10% and damage +10% |
| U23 | Rapid Orders | Rally cooldown -5 seconds; initial cooldown unchanged |
| U24 | Forced March | All troops movement +15% |

U01/U04/U07/U10/U13/U16 are the six behavior upgrades and receive the strongest explanatory previews. A preview uses approved in-engine clips or miniature UI illustrations, not a new tutorial scene.

### Edge conditions

Conscription increments only for successful paid Militia spawns. Bonus spawns never increment it. If the bonus would exceed the alive cap, store one owed bonus; no further bonus can be accumulated while owed. Spawn it at the next free slot during that battle. Clear the counter and owed bonus between battles. No currency refund for a bonus that remains unspawned when the battle ends.

Piercing Bolts uses the original snapshot damage before target mitigation for its secondary damage, then applies the secondary target’s mitigation normally. The additional enemy must be behind the first on the original flight path, no more than 1.5m further; the bolt never curves or hits a base as its secondary target. Splintering Head counts landed direct Ram base hits, not attacks started, troop hits, splash, or its own bonus. The bonus damage cannot trigger another proc. A killing direct base hit makes the bonus irrelevant; no duplicate victory event.

Sweeping Club evaluates additional unit targets at the primary impact; it excludes the primary ID, does not splash the base, and each target is hit once. Barrier HP uses the unit’s modified maximum HP at spawn and never refreshes from Rally. Heavy Boots and Forced March combine additively in the movement group. All these interactions require dedicated fixtures.

### Draft generation and rerolls

The first draft guarantees at least one eligible behavior upgrade among three distinct choices. Subsequent drafts include at least one eligible troop upgrade and, when available, at least one general upgrade. Exclude chosen upgrades and ineligible units; sample without replacement with the saved PRNG state. Four equipped units provide 12 troop-specific plus six general options before exclusions.

Everyone receives one free reroll per expedition. The second and last reroll is available through a rewarded ad or the permanent Ad-free Bonuses entitlement. Either reroll replaces the full current set; selection of an upgrade ends that draft. Reroll use is expedition-wide, not one per draft.

Persist the displayed offer and PRNG state before interaction. Restarting the application or revisiting the view must not redraw. A reroll saves the new offer and consumed allowance atomically. An ad failure consumes neither allowance nor current offer. No shop popup interrupts an upgrade choice.

## 6. Campaign, enemy policy, and replayability

Three chapters reuse three backgrounds: Border Fields, Timber Pass, Broken Keep. Each contains three expeditions of four battles. These are 36 data configurations, not 36 scenes or unique landscapes. Nine expedition names and all encounter queues are in the JSON registries.

Campaign progression is sequential: completing an expedition unlocks the next one, regardless of spending. Completed expeditions remain replayable. The existing concept of challenge modifiers is implemented through the encounter’s visible composition, base HP, Supply budget, and derived boss selection. There is no new separate challenge mode, daily rotation, or random rule generator.

Enemy behavior is intentionally a deterministic purchase queue with a finite bank, not adaptive machine learning. Each encounter declares starting Supply, regeneration, capacity, total spend budget, earliest deployment, minimum deployment gap, and the complete ordered troop queue. The next queued unit waits until affordable and under the alive cap. It is not substituted with a more convenient counter based on the player’s next tap. Remaining queue items are not silently spawned after the declared budget is exhausted.

Boss replacement substitutes one specified queued base troop and uses its original cost; this exception is explicit in the registry. The boss is shown at least three seconds before its earliest permitted deployment. The enemy never earns extra funds because the player refuses an advertisement, owns a purchase, loses repeatedly, or has a strong draft.

Battle variety comes from opening order, protection of ranged damage, when the costly unit arrives, queue composition, and visible stronghold pressure. Do not simply multiply all enemy HP every level. Numbers and queues in the current file are first-pass values requiring simulation and human testing.

## 7. Persistent economy and commercial limitations

Medals are earned, never purchased. Brute unlocks for 40; Ram for 80. Three earned cosmetic banners cost 120, 180, and 240. The initial four troops are free. Earned banners and the paid cosmetic set are cosmetic only; no stat-bearing prestige or duplicate sink exists.

Battle wins pay 10/15/20 by chapter. Expedition completion pays 20/30/40, and first completion adds 20. Defeats and draws pay no reward for the unresolved battle. Replay battle rewards are unchanged; first-clear bonus cannot repeat. Transaction IDs separate a legitimate replay from duplicate processing of the same win.

This means the first full introductory win supplies enough Medals to buy Brute without ads. All unlocks are finite. After every Medal sink is owned, hide the reward-bonus placement and stop claiming more Medals are useful. Do not add a new sink merely to maintain ad impressions. Players may retain an unused balance; no negative balances or wallet cap are needed for these small values.

**Known business weakness:** the economy exhausts quickly compared with an endless idle game. The enduring value must be combinations and replay, and the permanent ad-bypass product must be sold honestly. Its Medal benefit eventually ends; its extra-reroll benefit remains. The proposed $7.99 price is not validated and may be too high for the product’s depth.

## 8. Monetization and transaction behavior

Only two rewarded placements: the additional expedition reroll, and a +50% bonus on the sum of battle-win Medals from the just-ended expedition. Completion and first-clear Medals are excluded from that multiplier. Round the bonus down. The results bonus is eligible after at least one win, including a later defeat, but not during the introductory attempt and not when all Medal unlocks are owned. Each placement can grant once per run; maximum two ad-backed grants per run. No daily timers or ad quotas are added.

The reward text displays the actual value before consent: for example, “Watch an ad for +15 Medals.” The ordinary reward has already been saved. Continue is visible, equally functional, and never gated. Canceling, no fill, no connection, consent refusal, or SDK failure leaves the ordinary game intact. Standard rewarded ads require affirmative opt-in and promised reward fulfillment [S16].

A development build uses test ad IDs only. Production IDs are enabled by release configuration, never pasted into the editor test scene. Do not ask testers to click live advertisements. Gate requests through the current UMP flow and request eligibility [S13]. An ad-ready state cannot be inferred merely from having initialized the SDK.

### Reward receipt state machine

Placement eligible → user opts in → request/load → show → SDK reward-earned receipt → persist grant journal → apply once → close overlay/recover flow. Closing the overlay is not proof of earning a reward. If the reward callback arrives before close, save it immediately and apply the UI change when safe. If close arrives without the callback, keep the reward pending only for that show attempt and permit late callback handling; do not invent success.

Each attempt has a reward ID bound to run ID, placement, and draft/result checkpoint. Duplicate and out-of-order callbacks are idempotent. A successfully persisted reward receipt survives a crash. A process killed before any valid receipt is persisted cannot honestly be guaranteed a reward: the retry/support behavior must say that, rather than claim perfect offline transaction recovery. With no competitive or purchased currency, local ad-reward validation is an accepted limited-fraud surface; no extra real-time reward backend is required in this baseline.

### The two purchases

**Ad-free Bonuses:** one-time, proposed US base price $7.99. Both eligible rewarded actions become instant claims within the same limits. Everyone still receives their ordinary free reroll. There are no forced ads in the free version, so never describe this as removing forced interruptions. The listing explains the finite Medal benefit and persistent additional-reroll benefit.

**Cosmetic Army Pack:** one-time, proposed US base price $2.99. One coordinated banner/marking/fortress-trim/equipment-accent set. The store preview must show the actual changes; it is not six new troop designs or extra power. Price labels use store-returned localized prices, not hardcoded dollar strings.

Purchase states include store unavailable, purchasing, canceled, pending, purchased/unverified, verified/granted, already owned, restore in progress, refunded/revoked, and error. A pending payment grants nothing. Both products are non-consumable and restorable. Query ownership on foreground and on explicit Restore Purchases; do not consume these purchases.

Google recommends backend verification and acknowledgment, use of unique purchase tokens, and granting only after purchase verification. Unacknowledged purchases can auto-refund after three days [S12]. Implement a small separate entitlement service with idempotent grant and acknowledgment retry, rather than trusting a client boolean.

### Entitlement service boundary

One deployed service, one restricted datastore, one notification/reconciliation path. Verify package name, product, purchase state, token, acknowledgment status, and applicable fraud checks with Google. Keep tokens protected and out of analytics and logs. Store a token hash for deduplication and encrypt any token retained for provider calls. Restore of the same purchase is a read/revalidation, not a duplicate new sale.

There is no game login. Ownership recovery comes from the current Play account’s owned purchase tokens; an installation ID is not a substitute for proof of ownership. Cache a signed entitlement receipt locally for offline continuity. A backend timeout does not revoke an existing valid purchase. Revalidation can remove a refunded/revoked entitlement when online; immediate revocation while offline is not promised. Accept that local cheating cannot be eliminated in an offline game.

Use real-time developer notifications where supported and a scheduled reconciliation of voided purchases as a backstop; test duplicate, delayed, and missed notifications. Revoking an ad-bypass purchase removes future bypass grants, not already-earned Medals. Revoking cosmetics selects the default appearance without corrupting the army. Do not delete campaign progress as a punishment.

## 9. Animation decision — Unity-native cutout rigs

**Selected baseline:** side-view 2D cutout animation using separately exported transparent PNG parts, a parented transform/bone hierarchy, and Unity animation clips authored or generated in the editor. Rigid armor, shields, weapons, and limbs do not need complex mesh deformation. The same biped hierarchy is reused for five troop types; Ram uses a simple wheel/body hierarchy. This avoids a new paid animation dependency and avoids turning generated video into the runtime animation system.

Unity’s 2D Animation workflow supports separated artwork, rigs, and transform-driven bones; Sprite Skin is available for deformation where a rig genuinely needs it. The documented layered-import route depends on the installed PSD Importer version and supported formats [S02, S03]. Our canonical exchange is separate PNGs plus part/pivot metadata, so a Photoshop subscription and layered PSB export are not dependencies.

**Do not use Higgsfield video as the primary unit animation format.** A runtime attack must stop, die, change speed, and resume consistently; a baked video is not a rig. Generated video may inform motion studies or promotion, but it is not accepted as a walk/attack prefab. No 3D mesh pipeline, Blender rig, Mixamo dependency, or Spine licence is necessary for this selected visual scope.

### Character source requirements

Approve one neutral side-on master with complete body and weapon. Separate rear upper/lower arm, rear hand, rear upper/lower leg, rear foot, torso/hips, head, front upper/lower arm, front hand, front upper/lower leg, front foot, and weapon/shield as appropriate. Parts must include the concealed joint area, not stop exactly at the visible outline. Generate or repair missing shoulders, hips, hands, and back edges before rigging.

Each part record contains parent, local pivot, default position/rotation, pixels per unit, sorting order, attachment socket, source file, checksum, and approved silhouette reference. Some units combine rigid subparts; this does not change the logical skeleton. No mirrored text or asymmetrical emblems are baked into parts that will be flipped for the opposing team.

Use a common 1024px-high source character canvas, then size runtime sprites according to actual phone appearance. Target a normal troop height around 90–130px on a 1080px-high landscape reference display, with Brute clearly larger and Ram lower/wider. These are art targets to check, not reason to ship every master at full source resolution.

### Six states for every troop

Idle, Move, Attack, Hit reaction, Death, and Victory. This is 36 resolved troop/state combinations, largely derived from shared templates—not 36 independent AI-generated frame sequences. Bosses reuse the underlying troop’s state set with appropriate timing and silhouette accents.

Idle has subtle breathing; movement has grounded foot or wheel contact; attacks have anticipation, release/impact, and recovery; hit reaction is a short visual overlay rather than a gameplay stun; death stops targeting immediately and fades the body after a short bounded animation; victory plays only after outcome lock.

Five attack families are distinct: light melee strike, shield bash, crossbow release, grenade throw, heavy club; Ram is a sixth, mechanical strike. Weapon tips and projectile origins use explicit sockets. Runtime facing changes presentation and socket orientation, never the collision or targeting authority.

The attack clip is driven from the simulation’s normalized attack phase. Attack damage is emitted by the combat model; the visual hit must agree with it. If frames are skipped, damage still occurs exactly once. Hit reactions never cancel attacks unless the unit is dead; no undocumented stagger system is introduced.

### Who performs the animation work

Higgsfield supplies source art and individual repairs. Codex can implement the importer, metadata validation, hierarchical rigs, animation clip generation, unit prefabs, previews, and synchronization tests. Human work remains visual approval of silhouettes, joints, walking, attack impact, and the actual phone result. This is not a claim that every generated limb or procedural clip will be acceptable on its first attempt.

The proof sequence is Militia → Crossbowman → Ram, before the remaining roster. These establish a simple biped, a projectile attacker, and a non-biped. Required evidence: idle/move/attack/death loops in both directions, collision/attack debug overlays, 1x phone-scale preview, and a crowded battle. Failed foot contact or weapon grip means revise the source/rig, not generate the whole roster anyway.

## 10. Visual-asset production and provenance

Higgsfield is the approved visual provider in this plan. Generate the battle composition first, then master unit style, then segmented unit parts, then remaining troop masters, derived bosses, environments/bases, icons, and marketing assets. Do not mass-generate before the style and first animation proof pass.

Style rules: fixed side view, bold silhouettes, thick readable equipment, restrained surface detail, limited materials, common light direction, consistent outlines, and background contrast lower than troop contrast. Team identity uses banner shape/marking as well as color. Unit role is identifiable from shape, not a tiny label.

All source illustrations omit baked UI text. Buttons, health bars, numbers, prices, and upgrade descriptions are rendered in Unity. Keep a single licensed functional font family and record its licence; font files are not supplied in this planning package. Use scalable shapes/nine-slices for panels rather than generating dozens of near-duplicate panel images.

Three environments share identical walkable geometry and base positions. Background layers do not cover the troop silhouette region or imply a second traversable lane. Two base constructions support player/enemy variants through markings and decorative swaps; damage states are a healthy state, damaged overlay, and destroyed state, not three new building mechanics.

### Asset acceptance and handling

Every planned asset has a stable ID, intended use, provider/model or source, prompt/reference lineage, original source, derivative exports, generation/download dates, subscription rights evidence, technical metadata, approval status, and final checksum. Statuses: PLANNED → GENERATED → TECHNICAL_PASS → HUMAN_APPROVED → INTEGRATED → PHONE_VERIFIED. A pretty contact sheet does not establish the final binary or the integrated result.

Keep originals immutable. Name exports with stable IDs, not “final_final_2”. Keep accepted and rejected variants separate; never overwrite an accepted original during a regeneration. Record the superseded asset explicitly. No silent provider rerolls or unbounded batch spending.

Technical checks include alpha fringe against both dark and light backgrounds, sufficient joint overlap, silhouette at native size, outline consistency, correct facing, uniform scale/pivot, texture compression, atlas padding, no accidental text/watermark remnants, and no clipped animation frames. Respect provider provenance/watermark terms; ordinary asset processing must not be used to conceal required AI provenance [S04].

### Rights are a gate, not an assumption

Higgsfield’s current terms say it does not claim ownership of inputs/outputs or restrict commercial output use; they also disclaim uniqueness and place rights-clearance responsibilities on the user, with applicable third-party model policies still relevant [S04]. This does not make a generated imitation of an existing game’s character or logo safe.

Suno’s paid-rights help updated 3 September 2026 expressly permits video-game use for songs downloaded while subscribed [S05]. Its older non-retroactivity guidance warns against assuming later payment clears free-plan creations [S06]. The conservative production rule is create and download new game tracks while on the appropriate paid plan, store evidence of both dates and applicable terms, and avoid relying on old free-plan outputs without specific rights confirmation. Commercial permission is not a guarantee of copyright exclusivity.

ElevenLabs’ paid-use terms allow commercial use subject to applicable restrictions; its Sound Effects Terms additionally address sublicensing/opt-out behavior [S07, S08]. Retain source receipts and account/entity evidence; check any sharing settings before generating material intended to be distinctive. No celebrity voices, imitation songs, or third-party reference uploads without rights.

## 11. Sound, music, VFX, and haptics

### Music — Suno

Produce exactly two instrumental loops: Menu/Army and Battle. Target useful loop segments of approximately 60–90 seconds. Three short derived stings cover battle victory, defeat, and expedition completion. They can be edited from approved music rather than generated as unrelated tracks. No vocals, spoken words, lyric rights, or dynamic music system.

The tone is lightly martial and playful, with enough space for impacts. Musical phrases must not drown out attack transients. Export/download the highest usable licensed source available; create mastered runtime derivatives without upsampling a low-quality source and pretending it adds fidelity. Archive originals.

A generation is not automatically loop-ready. Inspect boundaries, trim or crossfade carefully, and audition multiple consecutive loops. Unity playback must be tested on Android for seams, decoder gaps, background/resume behavior, and audio focus. Menus crossfade into battle over approximately one second; ad/OS audio focus pauses or ducks the game correctly.

### Sound effects — ElevenLabs

Twenty-five sound families are enough: UI tap; confirm; cancel; error; deploy; troop unlock; draft choose; medal receipt; light swing; club swing; light impact; shield impact; heavy impact; crossbow fire; bolt impact; grenade release; explosion; Ram roll; Ram impact; soft death; heavy death; Rally; base damage; base destruction; overtime warning. Reuse and subtle runtime pitch/volume variation provide variety; do not generate a unique sound for every unit hit.

Generate isolated dry effects without music, voices, room ambience, or long silence. Trim start latency, tame peaks, remove DC offset where present, and inspect tails. Delivery masters use lossless PCM WAV when available; runtime import settings are chosen per clip length and memory cost. Short frequent clips are preloaded; music is streamed or compressed according to device tests. Mono effects with modest pan are sufficient; no spatial-audio feature is added.

Use separate Music, SFX, and UI mixer groups. Cap total simultaneous voices at an initial 24 and concurrent copies of an ordinary impact family at four. Priority: base destruction/result > Rally/heavy attack > ordinary impact > footsteps/ambient mechanical noise. Limit repeated full-army impact events instead of playing 24 identical sounds at equal loudness.

### VFX — Unity runtime, Higgsfield texture sources where useful

Twelve families: deploy dust, melee slash, light impact, shield block, bolt trail/impact, explosion, barrier, Rally, hit flash, death puff, Medal/UI reward burst, and base destruction. All are pooled. Use sprites, simple materials, and lightweight particles. A generated movie is not an interactive explosion system.

Gameplay never waits for an effect to finish. A kill frees the simulation actor immediately; its visual corpse has a bounded lifetime. Effects inherit the correct team/target position but do not change targeting. Cap ordinary particles initially at 400 total and enforce a small concurrent effect budget; reserve capacity for important impacts. These are performance targets to validate, not engine guarantees.

Haptics: light confirmation for major deployment/choice only if not noisy, stronger pulse for Rally or base destruction, none for every projectile. Settings separately control vibration, screen shake, and flashing intensity. Reduced motion disables shake and large UI scale bursts without hiding attack information. All important information must remain understandable with sound muted.

## 12. Complete interface and state coverage

Use Unity UI with a common scaling system and safe-area handling. Proposed reference canvas is 1920×1080 landscape. Both landscape orientations work. On unusual phone/tablet shapes, extend non-interactive scenery or letterbox; do not crop a base or allow hidden attack buttons. Touch targets aim for at least 48 density-independent pixels, verified in physical usage rather than guessed from source-canvas pixels.

| View | Required content and interactions | Required non-happy states |
|---|---|---|
| Home/Campaign | Current expedition; unlocked/replayable expeditions; Resume; Army; Shop; Settings | Locked expedition explanation; saved run active; offline; configuration fallback |
| Army | Six troop cards; four equipped slots; costs/stats/roles; unlock price; banner/set selection; briefing/Start | Insufficient Medals; locked troop; attempted duplicate slot; loadout locked during run; unavailable preview |
| Battle | Both base HP bars; Supply/cap; four deploy buttons; Rally; battle index; timer/overtime; pause | Not enough Supply; cooldown; unit cap; paused/backgrounded; recovery/restart; low-tier effects |
| Draft | Three choices; existing build summary; one free reroll; one extra reroll state; confirm/continue | Already used; no ad; loading/showing; receipt pending; instant paid entitlement; restored persisted offer |
| Results | Outcome; won battles; banked reward breakdown; completion/first-clear distinction; eligible bonus; replay/Home | Defeat; draw; abandoned; bonus unavailable; grant already applied; maximum progression |
| Shop | Two real product previews; localized price; purchase state; Restore; support/privacy references | Offline; product loading; unavailable store; canceled; pending; already owned; verifying; refunded |

Shared overlays: pause/settings, abandon confirmation, troop details, briefing, consent/privacy choices, purchase pending/error, save recovery notice, and support information. All overlays specify what closes them, whether back closes them, and whether simulation is paused. Android Back first closes a modal, otherwise opens battle pause, otherwise returns toward Home. Leaving the app does not accidentally abandon a run.

Settings include music/SFX volume, haptics, reduced motion/flash treatment, privacy controls, support, app/build version, Restore Purchases, and explicit Reset Local Progress. Reset is a two-step confirmation that retains purchased entitlements and does not imply a refund. Erasing local progress is different from requesting deletion of remotely held data; provide a documented privacy-request route.

All text is in a string registry with stable IDs even for an English-only launch. Do not bake text into sprites. Test long localized store prices and larger system font/display settings. A generated icon alone cannot distinguish loading from failure; each error has a plain-language reason and a functioning retry/continue path.

## 13. Technical architecture and dependency control

One Unity project and a small entitlement service. Within Unity, separate CombatModel, Content, Run/Progression, Save, Presentation, PlatformServices, and Editor/Validation assemblies or folders. Do not create microservices, a generalized game platform, or a custom ECS framework for 48 actors.

Combat is plain C# state plus pure math where possible. Rendering observes model events. Scene objects do not own persistent currency. UI commands are validated centrally. Content is a versioned registry compiled into runtime data; do not maintain an independent spreadsheet and ScriptableObject copy with different numbers. The selected JSON fields and schemas must be reviewed before implementation, then imported deterministically.

Use one bootstrap/menu scene and one reusable battle scene. Prefabs and ordinary bundled assets suffice; no remote addressable content service at launch. Runtime never calls Higgsfield, Suno, ElevenLabs, or a reasoning model. There is no per-player AI-generation cost.

Pin Unity patch, Android build support/SDK/NDK/JDK, C# backend, API level, graphics API, package versions, Firebase SDK, Google Mobile Ads/UMP, IAP adapter, and the actual resolved native Billing dependency. Commit package locks. Use the Unity-supported Android tooling combination rather than manually mixing recent Gradle components.

The candidate is Unity 6.3 LTS, which Unity lists as supported through December 2027 [S01]. The exact patch is a build-proof decision, not invented here. Target Android API 36 or above under the rule effective 31 August 2026 [S09]. Billing 7’s ordinary new-app/update deadline was 31 August 2026; choose a supported integration, normally Billing 8 or 9 at this date, and inspect the resolved dependency rather than trusting an adapter’s version number [S10, S30].

Proposed minimum device boundary: Android 9/API 28, ARM64, 3GB RAM, phone-first. This is a product proposal to approve after device coverage review, not a Play requirement. Use IL2CPP for release. Test all native libraries for 16KB-page compatibility and test on a suitable Android environment; a compatible Unity version alone does not prove every bundled SDK is compatible [S11].

### Environments and secrets

Development and production service projects are separated; staging/internal tests must never pollute production behavioral cohorts. A release manifest explicitly maps package, signing identity, Firebase app, ad units, products, backend endpoint, and content version. Production billing tests use appropriate Play test accounts and are excluded from revenue reporting.

No paid-provider API keys, service-account keys, signing passwords, purchase tokens, or user secrets in Git. Use protected secret storage and least-privilege roles. API endpoints and public Firebase configuration are not substitutes for access control. Only the entitlement service may write entitlement records; clients cannot write purchases directly into its database.

## 14. Saves, crashes, offline behavior, and upgrades

Versioned save contains settings, Medals, unlocked troops/banners, campaign completion, tutorial flags, selected cosmetics, active-run checkpoint, current draft/PRNG state, settled reward IDs, and cached signed entitlements. Do not use PlayerPrefs as the only authoritative progress store.

Write a new temporary file, flush as supported, verify, replace the active file, and retain a last-known-good backup. Transactions changing currency and an unlock occur in the same save. On low disk space or failed write, do not report a successful unlock; retain the prior valid state and show a recoverable error. Checksum detects accidental corruption, not a sophisticated attacker.

Recovery order: valid latest save → valid backup → informed reset only when neither can be used. Keep a recoverable corrupt copy for user-authorized diagnosis without uploading it by default. Never reset an unknown newer schema silently. Save migrations have fixtures for every publicly released prior version we support.

Offline core play is unconditional after install. Missing analytics, consent-network response, ads, remote config, or entitlement service does not block the battle. Fresh purchases cannot complete without store/service access. Restored purchases may need online verification. Cached valid ownership is not removed simply because a network request fails.

Explicitly configure Android backup/device-transfer rules. The launch promise is local progress only; exclude entitlement secrets and do not claim a partial OS backup is reliable cloud save. A reinstall or device change may lose campaign progress while Play purchases remain restorable. State this before reset/support troubleshooting.

A running expedition pins its balance/content version. Remote changes activate only at safe boundaries. An app update with compatible saved-run data resumes it; a genuinely incompatible version must preserve banked rewards, explain the interrupted run, and record the migration. Never reinterpret an old run silently with new unit IDs.

## 15. Analytics plan, data quality, and dashboards

Use Firebase Analytics for behavior, Crashlytics for failures, Remote Config for bounded service switches, and BigQuery export for raw cohort analysis when configured. These Unity/service integrations are documented by Google [S17–S20]. A dashboard can use a versioned query layer and a simple reporting front end; it is not a reason to add another mobile SDK.

The supplied registry defines **35 custom events**, not hundreds of per-hit messages. The shared envelope includes event ID, app version, balance version, environment, and session ID. Event-specific run/draft/attempt/transaction IDs enable deduplication. High-cardinality IDs belong in raw exports, not as custom reporting dimensions. Events omit raw purchase tokens, emails, full order IDs, free-form messages, precise location, and advertising identifiers.

Core sequence: game_boot → tutorial_step → expedition_start → battle_start/end → draft_offered/chosen → expedition_end. Battle summaries aggregate unit spawns, effective damage, base damage, deaths, live time, peak population, and wasted Supply. At most one per troop type/side per ended battle; no attack-by-attack telemetry.

Draft analytics record all offers and their positions as well as chosen options, because selections without offer denominators are misleading. Track the exact offer ordinal before/after rerolls. Army and upgrade outcomes must be examined by experience/progression and encounter; selection-win correlation does not prove the upgrade caused the win.

### Privacy and collection controls

Legal/consent configuration is a pre-integration gate. UMP handles advertisement privacy flows; it does not automatically settle consent or lawful-basis questions for every analytics/crash component. Configure collection defaults deliberately and verify actual outgoing traffic with consent denied, accepted, and withdrawn. Do not retroactively transmit a pre-consent behavioral backlog. Essential restricted purchase records are separated from optional behavioral analytics.

Proposed data-retention design: 90 days for identifiable raw behavioral export, aggregated non-identifying business trends thereafter, and financial/entitlement records for the period actually required by business/legal obligations. These are proposals, not legal conclusions. Regional hosting, access rights, deletion handling, and provider processing terms must match the approved market/audience plan.

### Revenue measurement

Use AdMob impression-level paid callbacks, including value, currency, and precision, for estimated impression revenue [S14]. Link SDK-generated ad reporting carefully: do not manually send a duplicate GA4 ad_impression when the integration already records it. Callback timing, duplicate handling, and final payout reconciliation must be tested. Ad requests, impressions, completed ads, rewards, and cash paid are different quantities.

Backend-verified purchases and later revocations are the canonical entitlement/financial records. Choose one canonical analytics purchase projection; do not add client purchase success to automatic purchase tracking and count both. Analytics receipts are not bank statements. Exclude testers and test orders. Reconcile gross sales, taxes handled by the platform, platform fees, refunds, withholding where applicable, currency conversion, and net settlements using actual provider reports—not a hardcoded assumption that every purchase nets the same percentage.

### Six dashboard pages

**Health:** crash-free users/sessions, app-not-responding reports, startup, save failures, purchases stuck pending, reward failures, backend errors/cost. Include app version, device tier, and country where available and privacy-appropriate.

**Acquisition:** store visitors, acquisitions, first opens, source attribution, creative ID, and install-to-first-battle conversion. Play Install Referrer can support attribution [S28]; do not pretend it measures every organic exposure or solves all campaign attribution.

**Retention:** exact Day-1/7/30 active return rates and cohort sizes. Define day windows once: elapsed 24-hour bins from first observed open, not a mixture of local calendar dates and elapsed time. An active return requires foreground engagement, not background SDK work. Separate production players from friends/testers and show privacy-related missingness.

**Gameplay:** expedition starts/completions, per-battle win/loss/draw, attempts, battle duration, base-damage conversion, roster usage, Supply waste, Rally timing, and draft offer/choice distributions.

**Monetization:** rewarded-offer opt-in, fill/show/earn/grant funnels, impression eCPM, ad ARPDAU, buyer conversion, net purchase revenue, refunds, and ad-bypass ownership. Ad-bypass users have different ad exposure by design; count that opportunity cost.

**Cohort economics:** cumulative revenue and variable service cost per acquired install by cohort; D7/D30/D60 where mature; country and source cuts only where sample size supports them. Distinguish observed revenue from extrapolated lifetime value. Do not treat future lifetime revenue as measured.

### Quality gates for measurement

Script a known journey and verify exact event counts in a development environment, then the raw export and dashboard. Repeat interruption/duplicate callback cases. Verify version/source tags. No statistical conclusion from ten cooperative testers. Provisional investigation targets remain D1 around 35%, D7 10%, D30 3%; these are internal hypotheses, not sourced industry benchmarks or proof of a good business.

An illustrative cohort of 200 is still imprecise, especially for purchase conversion. Use uncertainty intervals, report denominators, and wait for the cohort to reach the metric’s age. No unrequested paid user acquisition or live A/B test is authorized. Sequential tuning must be version-tagged and interpreted with country/source/device shifts in mind.

## 16. Remote configuration and operational safety

Remote Config has a small allowlist: ads enabled, purchases enabled, a specific placement enabled, support notice, and approved bounded configuration version selection. Local defaults keep the game playable. Failed/malformed/stale fetches retain a known-good configuration. No remotely supplied executable code, arbitrary asset download, or silent price override.

Emergency switches stop new requests, not erase ownership or cancel rewards already earned. A live paid benefit must continue to work from its entitlement path when the ad network is down. A local client cannot instantly receive a kill switch while offline; that limit belongs in the incident plan.

No per-player difficulty changes, payer-targeted enemy scaling, randomized shop prices, or undocumented offer personalization. Any balance adjustment requires a versioned content review, regression evidence, and a safe activation boundary. The initial release can keep balance entirely bundled and use remote config only for service safety.

## 17. Performance, device testing, and accessibility

Initial engineering budgets: 60fps on the primary mid-range test device; a stable 30fps presentation mode on the agreed lower tier; 20Hz simulation unchanged; no routine per-frame heap allocation in hot combat paths; at most 48 live units, 80 live simulation projectiles, and a bounded particle/audio budget. Preallocate pools and give exhaustion a documented behavior. Do not silently drop a gameplay projectile because its visual pool is full; simulation damage remains authoritative.

Provisional download target is under 150MB and steady-state process memory under 500MB on the lower-tier device, including SDK effects. These are internal targets to profile, not Google Play limits. Test cold start, warm start, 20-minute play, repeated battle loads, ad transitions, purchases, and background/foreground cycles. Watch frame-time percentiles and heat-related degradation rather than average FPS alone.

Required physical coverage: the owner’s primary Android phone (exact model to be confirmed), an actual lower-tier Android device, and at least one materially different GPU/device family. Emulators supplement physical devices, including 16KB testing; they do not establish thermal behavior or touch feel. A tablet/foldable aspect-ratio pass ensures the advertised supported devices do not lose critical UI.

Test no-network, slow/interrupted-network, storage nearly full, system font/display scaling, both landscape orientations, cutouts, gesture navigation, Bluetooth/headphones, silent mode, incoming calls, audio focus, and notifications over gameplay. No camera, microphone, contacts, storage-browsing, or location permission is needed by the core game. Inspect merged manifests so an SDK does not unexpectedly expand permissions.

Accessibility acceptance: readable icon silhouettes, no color-only affiliation, adjustable audio/haptics, reduced motion/flash, no rapid full-screen strobe, touch targets that remain usable at the narrowest supported aspect ratio, and all commercial actions clearly labeled. No claim of complete screen-reader accessibility without testing the actual Unity implementation.

## 18. Build process, source authority, and one-shot experiment

Finish this candidate’s decisions, review the data, and freeze an approved source package before production. The package’s current status is not that freeze. The source hash, decision log, content registries, acceptance criteria, and approved visual references become the implementation authority. Conflicts stop the task and are resolved in source—not hidden in code.

Use a new game repository/project rather than copying another game’s runtime. Reuse independently reviewed generic tooling only when its licence and dependencies are clear. No Roman Legacy/BBGL/Reactorfall content, monetization obligations, or server design automatically transfers to this game.

The authoring model receives a bounded task with source version/hash, allowed changes, forbidden changes, acceptance criteria, evidence paths, and a stopping condition. It may use the highest reasoning setting the owner chooses; model strength is not evidence that the build or game is correct. Human approvals remain for spending, final visuals, credentials/signing, public URLs, legal identity, and publishing.

### Proof gates and dependency order

| Gate | Outcome | Required evidence and exit rule |
|---|---|---|
| G0 — Source freeze | Approved rules, commercial terms, audience/markets, visual direction, registries | No unresolved core-rule contradictions; owner decision log; frozen hash |
| G1 — Toolchain/service skeleton | Clean Unity Android project and CI/build path | Fresh checkout build; pinned packages; API/Billing/native dependency report; secrets isolated |
| G2 — Asset/animation proof | Militia, Crossbowman, Ram at real phone scale | Layer/pivot audit; six states; both facings; projectile/impact sync; visual approval |
| G3 — One-shot core attempt | One full four-battle expedition with four starter units and existing mechanics | Playable APK; source-mapped tests; save/restart; win/loss/draw; stubbed non-production services clearly marked |
| G4 — Core correction gate | Independent review of the actual G3 head | Findings fixed; exact-head tests; phone playthrough; no claim that first attempt was perfect |
| G5 — Full bounded content | Six troops, 24 upgrades, nine expeditions, 36 encounters | Registry validation; balance simulation; all loadouts; final assets/audio integrated |
| G6 — Real services | Consent, ads, purchases, entitlement backend, analytics dashboards | Real test flows; restore/refund/dedup; event reconciliation; no secrets in client |
| G7 — Release candidate QA | Stable signed build and support/privacy readiness | Device matrix, migrations, performance, pre-launch report, source/build manifest |
| G8 — Closed validation | Independent players can understand and replay it | Observed funnel/retention; failures triaged; no invented commercial validation |
| G9 — Limited first production | Owner-approved markets, store, billing, ad readiness | First-release checklist; actual published build matches approved AAB; services monitored |
| G10 — Maintenance/expansion decision | Fix defects and assess economics | Cohort evidence; reconciled settlements; updates staged; no automatic feature expansion |

G2 is a narrowly authorized proof after source freeze and the G1 toolchain check, not permission to mass-produce all visuals before approval. External publisher setup can proceed alongside G1 where independent. G3 uses temporary placeholders for unfinished content but must never mark those placeholders final. G5 cannot paper over a failed G4 game-feel gate.

### What “one shot” means here

One initial implementation attempt covers the full bounded core loop in a branch. Record prompt, source hash, model setting, starting commit, resulting commit, build artifact hashes, tests, and deviations. Follow-up fixes are recorded as follow-up fixes. The experiment is not redefined as successful merely because scaffolding compiles.

It does not claim to one-shot commercial licence evidence, human art approval, merchant verification, store review, real device performance, or player retention. Those have separate proof gates regardless of implementation model.

### Continuous integration and review

On each relevant change: schema/reference validation, pure-model unit tests, Unity EditMode/PlayMode tests, save-migration tests, and a build smoke test. Nightly scheduling is not required; run on approved branch/push/manual triggers according to cost limits. Local Windows build automation is acceptable for this solo workflow; no cloud-build subscription is assumed.

Require a fresh independent code review on the exact implementation head, not an old head with new commits. An evidence packet records command, environment, time, exit code, test counts, important logs, screenshots/recordings, and artifact hashes. “Looks good” is not a test result. Never substitute unit tests for a touch-input/device test.

Protect main; keep source changes separately reviewable; no silent merging or advancing to the next production gate. For a failed task, preserve the failing reproduction and evidence before repair. Do not spend days preserving an arbitrary maximum script count; bounded features and testable contracts matter more than artificial code-file limits.

## 19. Testing and balance validation

Structural tests: six unique troops, 24 unique upgrades, six behavior upgrades, four distinct equipped slots, 36 encounter IDs assigned once, nine ordered expeditions, valid asset/product/event references, valid source IDs, and no unreachable or empty draft pool.

Combat unit tests cover cooldowns, insufficient funds, exact-cap deployment, tick order, attack snapshots, rounding, flat reduction, barriers, melee range at impact, projectile target death, piercing, splash boundaries, boss substitution, Rally boundary ticks, simultaneous base deaths, overtime, and integer tie resolution.

Balance tests use the same combat model as the game. Compare all 15 loadouts, many seeded draft paths, spam-one-unit policies, mixed protected-damage policies, hoard-then-push policies, and Rally timing. Separate equal-budget isolated matchups from full encounter performance. Report seeds, quantities, and policy assumptions. A bot is not a human player and cannot prove fun or retention.

Every permitted upgrade pair is checked for accidental recursion, double application, cost rounding, stale snapshots, and runaway attack rate. Ineligible units never appear in draft offers. Test that a bonus unit is not a paid deployment. A single powerful build is not automatically a defect; a nearly universal dominant strategy that makes the remaining choices irrelevant is.

Economy tests: every grant settled once, repeated app foreground does not regrant, failures retain previous wins, reset does not erase purchases, first-clear pays once, replay pays normally, bonus excludes first-clear/completion amounts, no more than one extra reroll/run, and finite-sink offer suppression.

Service tests: consent states; no-fill; late/duplicate reward callbacks; killed app; billing cancel/pending/failure; ownership restored after reinstall; backend outage; missed notification; refunded purchase; store/account change; missing product; localized price; current and previous app versions against the backend; analytics collection disabled.

A release cannot pass with a known progress-loss defect, duplicated charge/grant, unintentionally live test ad behavior, misleading paid entitlement, critical crash, unreadable primary UI, or unresolved required privacy declaration. Minor cosmetic defects require explicit documented acceptance; they are not silently ignored.

## 20. Publisher, legal, privacy, and store preparation

Use the owner’s intended Macedonian-company organization route, with the company’s exact verified legal details and the chosen public publisher identity supplied by the owner. This plan does not claim the D-U-N-S, Play account, or payment setup has already completed. Google’s organization requirements include verified identity/contact/website and D-U-N-S information; its current supported-locations table includes North Macedonia for developer and merchant registration [S25, S26].

Start identity, payments, domain, privacy/support pages, and product setup before the final game is ready. They are external dependencies, not tasks that Codex can satisfy with code. Keep banking/tax identifiers out of repository documents. Record only the completion evidence and secure credential locations.

Choose the final game title and package ID before store setup. “One Lane War” is a working name, not trademark clearance. Check market/store conflicts and obtain any needed rights review. Public publisher name may differ from the legal company, but disclosures must use the correct entity. Set up operational support email, public privacy policy, app support page, and necessary purchase/data-request information.

The Data safety declaration must reflect actual Firebase, advertising, billing, support, and backend collection—including third-party SDK behavior—not merely that battles work offline [S21]. Complete content rating, audience/ads declarations, country distribution, access instructions, export/compliance prompts where applicable, and any applicable regional trader/privacy requirements using the final build and markets. Do not guess an IARC rating.

No account-creation feature is added merely to satisfy a hypothetical deletion flow. Still provide a real route for relevant privacy requests concerning any data held remotely. Explain local reset, local progress loss, purchase restoration, and refund handling separately. Required record-retention obligations must be reconciled with deletion requests before launch.

### Store assets and listing

Create the final icon, feature graphic, and at least six planned phone screenshots showing actual gameplay, draft choices, troop roles, progression, and truthful purchase/ad positioning. Production dimensions/formats follow the live Play Console guidance at export [S27]. Do not guess changing promotional requirements from memory.

Prepare a concise gameplay trailer and three reusable authentic short clips: swarm reversal, protected firing line, and Ram finish. Higgsfield may help with supporting graphic production/editing, but store gameplay shots must correspond to the shipped mechanics and attainable play. No fake gameplay, fake reviews, misleading “offline” claims that conceal purchase limitations, or a trailer made entirely of an unrelated cinematic.

Store text explains four-unit armies, run-based upgrades, offline core play, optional rewarded ads, permanent purchases, and local-only progress. It must not promise endless content or cloud synchronization. There is no incentivized review request and no screen that sends happy users to public reviews while diverting unhappy users away.

## 21. Google Play shipping process

Prepare release AAB with version name/code, final signing configuration, release stripping/linker rules, required permissions, current API/Billing dependencies, all assets, and no debug menus/test credentials. Upload symbols and mapping files; Crashlytics Android IL2CPP native reporting requires symbol handling for useful stacks [S18]. Verify a test crash and recoverable error in a controlled build before release; remove crash-trigger controls from production.

Enable Play App Signing and protect the separate upload key. Back up recovery information securely. Review the bundle’s generated device APKs where applicable, resolved SDK inventory, native-library alignment, signing, installed version, and download size. Test the artifact installed through Play, not only a sideloaded APK.

Internal track is the first distribution gate; closed testing follows with people outside the development loop. Google’s 12 continuously opted-in testers/14-day rule specifically applies to relevant new personal accounts; do not automatically describe it as a universal organization-account requirement [S24]. Regardless of account type, real closed testing remains a project quality requirement.

AdMob requires app-ads.txt verification and app-readiness approval before full serving [S15]. Host the file on the developer website associated with the store listing, confirm crawlability, link the correct app, and finish readiness review. Until ready, the game must handle unavailable ads cleanly. Test successful store purchases and owner payout setup separately from advertisement readiness.

### First production versus updates

Google does not offer a rollout percentage for an app’s first release: it becomes available to all users in the selected countries. Limit first exposure using testing tracks and a deliberately approved small country set, not a fictitious “5% first launch” [S22]. The proposed English-first market plan is a decision, not authorization to publish globally.

For subsequent updates, use staged percentages where available, for example 5% → 20% → 50% → 100%, with advancement based on actual sample/error evidence rather than a timer. Halting stops further rollout but does not roll back the installed binary on existing devices [S23]. Prepare a higher-version-code fix-forward build and server/config rollback; do not promise an in-place downgrade of saved data.

Review submission and publishing are owner-controlled actions. A reviewer approval does not prove the game’s economy works. Record exactly which AAB hash, source head, package locks, content version, backend version, and configuration were released. Keep reviewer instructions and service availability sufficient for a reviewer to reach the main gameplay without a purchase or ad.

### Launch checklist

All required owner decisions resolved; source freeze recorded; critical tests passed; accepted final assets present; rights ledger complete; support/privacy pages public; audience/countries approved; products/restoration/refunds tested; no live test artifacts; analytics consent and data flows verified; AdMob readiness checked; symbols uploaded; backup/recovery tested; real Play-installed smoke test completed; alerts and operational access tested; owner explicitly approves publication.

Publishing code, enabling real commercial services, spending advertising money, and increasing country distribution are separate permissions. None is implied by this planning document.

## 22. Acquisition, business accounting, and validation

Baseline acquisition uses actual gameplay clips, the store listing, permitted organic community posts, a small press/creator kit, and individually relevant outreach. No scraping/spam campaign, bought reviews, deceptive ads, or unapproved ad spend. Track source links where technically supported and label unattributed installs honestly.

Creative concepts correspond to three existing army builds; no extra minigame is developed for advertising. Produce clips during approved gameplay capture, not after the game is “finished.” A marketing asset is accepted only after its depicted moment is reproduced in the release candidate.

The financial model separates fixed costs, variable costs, cash timing, and owner labour. Fixed: provider subscriptions/credits, domain/support infrastructure, devices, build tooling, any necessary legal review. Variable: backend requests/storage, reporting queries, and any later explicitly approved acquisition. A provider subscription already owned may have low incremental cost, but generation credits/retries and attribution to the project still belong in the ledger.

No precise hosting quote is justified without deployed request and storage volumes. Budget the small entitlement service by verified requests, notification/reconciliation frequency, database reads/writes, logs, raw analytics export, and dashboard queries. Keep log retention bounded and default maximum instances/query budgets reasonable. Alerts-only cloud budgets are not automatic hard caps; the current provider documents distinguish alerts from supported spend-cap functionality [S29].

Monthly close reconciles Play and AdMob provider reports to bank settlements and records credits/refunds/fees/taxes/FX under the company’s actual accounting treatment. Report gross purchases, net receipts, ad estimated revenue, final ad earnings, cash received, hosting/provider expenses, acquisition spend, and founder time separately. Do not call gross receipts profit.

Commercial contribution per acquired user = cumulative net purchase receipts + final/estimated ad receipts (clearly labeled) − attributable variable costs − acquisition cost. Lifetime estimates must state assumptions and uncertainty. A finite campaign with two non-recurring products may need a steady flow of new players; do not treat one-time buyers as subscription revenue.

Stop or narrow production when: the core remains boring after a bounded correction pass; reliable consent/payment/save handling exceeds the accepted maintenance budget; no organic reach exists and paid validation is not authorized; or observed unit economics do not support further spending. Fix presentation/clarity first where evidence points there. Do not automatically rescue a weak game by adding excluded systems.

## 23. Post-launch operations, maintenance, and sunset

Operational review priorities: progress-loss/purchase failures first; crashes/ANRs next; ad-grant failures and backend costs; then onboarding, content balance, and store feedback. A solo operator still needs real alert routing, access recovery, and a documented response when unavailable. This plan does not create scheduled notifications or claim background monitoring has been configured.

Critical incident playbook: identify affected build/config/cohort; preserve logs without exposing personal data; disable only the broken purchase/ad entry point if needed; retain existing entitlements; halt an update where possible; deploy a tested server/config rollback or fix-forward app build; verify recovery; record root cause and regression coverage. A kill switch cannot fix a completely offline client until it reconnects.

Before every update, rerun migrations, restore/refund handling, privacy/SDK inventory review, platform-policy check, native compatibility, core regression, and Play-installed smoke tests. Stage updates and retain the previous backend contract long enough for installed clients to function. Do not remove a known-good fallback merely to tidy the codebase.

Back up source, accepted master assets, prompts/rights evidence, release binaries/symbols, content manifests, and entitlement records. Keep at least one copy independent of the primary workstation/repository service. Test restoring the build and datastore; a backup that has never been restored is not proof of recoverability.

If the game is retired: stop new acquisition/spending; disable new purchases before abandoning service; preserve offline play and already-paid benefits where feasible; publish clear support/service expectations; retain required financial records; expire unnecessary personal data; and avoid simply deleting the entitlement backend while the store still sells the product. No service-duration promises are invented in this baseline.

## 24. Owner decisions and approval boundaries

Decisions needed before a source freeze: final visual tone/orientation approval; target audience and launch-market/language set; spending ceilings; approval of local-only progression/no account; final purchase-value/price direction; publisher/title/package/support identities. The provider names are interpreted as Suno and ElevenLabs, not additional tool recommendations.

The proposed defaults are landscape comic-medieval, English, adult/older strategy audience subject to honest rating/declarations, no paid acquisition initially, offline battles/local progress, two permanent purchases, and the limited scope defined above. Defaults are proposals; they do not authorize costs, services, or publishing.

Technical unknowns are assigned proof gates rather than disguised as owner questions: exact compatible Unity/SDK versions, acceptable rig quality, combat balance, lower-tier performance, ad fill, billing recovery, conversion, and retention. The owner does not need to guess these; the project must produce evidence.

**What is complete now:** coverage of the intended product, content candidates, mechanics/edge cases, asset and animation contracts, service boundaries, build/release gates, analytics definitions, QA and operations responsibilities.

**What is not established:** human approval, final external account/rights evidence, executable Unity behavior, successful combat simulation, finished assets, verified devices/SDK integration, legal compliance of a final build, or commercial performance. Structural checks in this package must never be cited as those results.

## Appendix A. Registry and evidence map

`data/game_rules.json` defines the scope and major constants. `units.json`, `upgrades.json`, `boss_variants.json`, `encounters.json`, and `expeditions.json` provide complete proposed content records. `economy.json` and `products.json` bind rewards and paid entitlements. `analytics_events.json` defines the 35 custom events. `assets.json` defines 148 planned asset-family/state/UI/marketing records (not generated files). `animation_contract.json` defines rigs and approval fields. `qa_cases.json` defines 93 required checks, all NOT_RUN. `build_gates.json` defines the 11 dependency gates, and `open_decisions.json` records owner/proof decisions.

`evidence/STRUCTURAL_VALIDATION.md` reports only checks actually run on these planning files. `validate_plan.py` repeats them. `MANIFEST.json` records package file hashes. This is not a game-test report.

When a human-approved frozen source is created later, attach approved visuals and the exact source manifest to the implementation task. Until then, `production_authorized` remains false.

## Appendix B. Primary sources

The linked source index below supports external/provider facts. The gameplay, budgets, thresholds, counts, and schedules in this document are original proposals, not claims copied from these sources. Package-version example documentation is not a version pin. Sources checked 27 September 2026.

- **[S01] [Unity 6 support](https://unity.com/releases/unity-6/support)** — checked 2026-09-27.
- **[S02] [Unity preparing artwork](https://docs.unity3d.com/Packages/com.unity.2d.animation@11.0/manual/PreparingArtwork.html)** — checked 2026-09-27.
- **[S03] [Unity Sprite Skin](https://docs.unity3d.com/Packages/com.unity.2d.animation@10.2/manual/SpriteSkin.html)** — checked 2026-09-27.
- **[S04] [Higgsfield Terms](https://higgsfield.ai/terms-of-use-agreement)** — checked 2026-09-27.
- **[S05] [Suno paid subscription rights](https://help.suno.com/en/articles/9601665)** — checked 2026-09-27.
- **[S06] [Suno non-retroactive rights help](https://help.suno.com/en/articles/2425729)** — checked 2026-09-27.
- **[S07] [ElevenLabs terms, non-EEA](https://elevenlabs.io/terms-of-use)** — checked 2026-09-27.
- **[S08] [ElevenLabs Sound Effects Terms](https://elevenlabs.io/sound-effects-terms)** — checked 2026-09-27.
- **[S09] [Google Play target API policy](https://support.google.com/googleplay/android-developer/answer/11926878?hl=en)** — checked 2026-09-27.
- **[S10] [Play Billing deprecation](https://developer.android.com/google/play/billing/deprecation-faq)** — checked 2026-09-27.
- **[S11] [Android 16 KB support](https://developer.android.com/guide/practices/page-sizes)** — checked 2026-09-27.
- **[S12] [Billing security and verification](https://developer.android.com/google/play/billing/security)** — checked 2026-09-27.
- **[S13] [AdMob UMP for Unity](https://developers.google.com/admob/unity/privacy)** — checked 2026-09-27.
- **[S14] [AdMob impression-level revenue](https://developers.google.com/admob/unity/impression-level-ad-revenue)** — checked 2026-09-27.
- **[S15] [AdMob app-ads.txt verification](https://support.google.com/admob/answer/14538460?hl=en)** — checked 2026-09-27.
- **[S16] [Rewarded-ad policy](https://support.google.com/admob/answer/7313578?hl=en)** — checked 2026-09-27.
- **[S17] [Firebase Analytics Unity](https://firebase.google.com/docs/analytics/unity/get-started)** — checked 2026-09-27.
- **[S18] [Firebase Crashlytics Unity](https://firebase.google.com/docs/crashlytics/unity/get-started)** — checked 2026-09-27.
- **[S19] [Firebase Remote Config Unity](https://firebase.google.com/docs/remote-config/unity/get-started)** — checked 2026-09-27.
- **[S20] [Firebase BigQuery export](https://firebase.google.com/docs/projects/bigquery-export)** — checked 2026-09-27.
- **[S21] [Google Play Data safety](https://support.google.com/googleplay/android-developer/answer/10787469?hl=en)** — checked 2026-09-27.
- **[S22] [First release and rollout](https://support.google.com/googleplay/android-developer/answer/9859348?hl=en)** — checked 2026-09-27.
- **[S23] [Staged update rollouts](https://support.google.com/googleplay/android-developer/answer/6346149?hl=en)** — checked 2026-09-27.
- **[S24] [Personal-account test requirement](https://support.google.com/googleplay/android-developer/answer/14151465?hl=en)** — checked 2026-09-27.
- **[S25] [Play organization identity](https://support.google.com/googleplay/android-developer/answer/13628312?hl=en)** — checked 2026-09-27.
- **[S26] [Supported merchant countries](https://support.google.com/googleplay/android-developer/answer/9306917?hl=en)** — checked 2026-09-27.
- **[S27] [Play preview assets](https://support.google.com/googleplay/android-developer/answer/9866151?hl=en)** — checked 2026-09-27.
- **[S28] [Install Referrer](https://developer.android.com/google/play/installreferrer)** — checked 2026-09-27.
- **[S29] [Cloud budget alerts](https://cloud.google.com/billing/docs/how-to/budgets)** — checked 2026-09-27.
- **[S30] [Unity IAP changelog](https://docs.unity3d.com/Packages/com.unity.purchasing@5.0/changelog/CHANGELOG.html)** — checked 2026-09-27.
