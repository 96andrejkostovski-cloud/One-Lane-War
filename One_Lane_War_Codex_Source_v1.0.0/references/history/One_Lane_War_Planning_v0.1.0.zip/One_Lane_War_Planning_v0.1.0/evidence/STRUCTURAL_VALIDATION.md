# Structural validation — planning files only

**Result: PASS**
Checks evaluated: 775. Failed: 0.

This script checks JSON parsing, counts, identities, cross-references, queue budget arithmetic, scope flags, asset/QA pending status, and gate ordering. It does not run Unity, simulate combat, render assets, validate licences, test services/devices, or establish commercial performance.

All game QA cases remain **NOT_RUN**. All production gates remain **NOT_STARTED**.

| Check | Result | Detail |
|---|---|---|
| All planning registries parse as JSON | PASS | 15 registries |
| Units: unique IDs | PASS |  |
| Upgrades: unique IDs | PASS |  |
| Encounters: unique IDs | PASS |  |
| Expeditions: unique IDs | PASS |  |
| Bosses: unique IDs | PASS |  |
| Assets: unique IDs | PASS |  |
| Gates: unique IDs | PASS |  |
| QA: unique IDs | PASS |  |
| Events: unique IDs | PASS |  |
| Sources: unique IDs | PASS |  |
| Products: unique IDs | PASS |  |
| Decisions: unique IDs | PASS |  |
| Count: troops | PASS | 6 / 6 |
| Count: upgrades | PASS | 24 / 24 |
| Count: encounters | PASS | 36 / 36 |
| Count: expeditions | PASS | 9 / 9 |
| Count: bosses | PASS | 2 / 2 |
| Count: purchases | PASS | 2 / 2 |
| Count: custom_events | PASS | 35 / 35 |
| Count: gates | PASS | 11 / 11 |
| No source approval or production authorization asserted | PASS |  |
| Balance explicitly untested | PASS |  |
| No accounts or cloud progression silently added | PASS |  |
| No forced ads | PASS |  |
| Single currency; no premium currency | PASS |  |
| Only four initial troops | PASS |  |
| Six behavior upgrades | PASS |  |
| Six general upgrades | PASS |  |
| Unit militia asset/rig | PASS |  |
| Unit militia valid numeric seeds | PASS |  |
| Unit militia windup | PASS |  |
| Unit shieldguard asset/rig | PASS |  |
| Unit shieldguard valid numeric seeds | PASS |  |
| Unit shieldguard windup | PASS |  |
| Unit crossbowman asset/rig | PASS |  |
| Unit crossbowman valid numeric seeds | PASS |  |
| Unit crossbowman windup | PASS |  |
| Unit grenadier asset/rig | PASS |  |
| Unit grenadier valid numeric seeds | PASS |  |
| Unit grenadier windup | PASS |  |
| Unit brute asset/rig | PASS |  |
| Unit brute valid numeric seeds | PASS |  |
| Unit brute windup | PASS |  |
| Unit ram asset/rig | PASS |  |
| Unit ram valid numeric seeds | PASS |  |
| Unit ram windup | PASS |  |
| Upgrade u01 references | PASS |  |
| Upgrade u01 no extra rank | PASS |  |
| Upgrade u02 references | PASS |  |
| Upgrade u02 no extra rank | PASS |  |
| Upgrade u03 references | PASS |  |
| Upgrade u03 no extra rank | PASS |  |
| Upgrade u04 references | PASS |  |
| Upgrade u04 no extra rank | PASS |  |
| Upgrade u05 references | PASS |  |
| Upgrade u05 no extra rank | PASS |  |
| Upgrade u06 references | PASS |  |
| Upgrade u06 no extra rank | PASS |  |
| Upgrade u07 references | PASS |  |
| Upgrade u07 no extra rank | PASS |  |
| Upgrade u08 references | PASS |  |
| Upgrade u08 no extra rank | PASS |  |
| Upgrade u09 references | PASS |  |
| Upgrade u09 no extra rank | PASS |  |
| Upgrade u10 references | PASS |  |
| Upgrade u10 no extra rank | PASS |  |
| Upgrade u11 references | PASS |  |
| Upgrade u11 no extra rank | PASS |  |
| Upgrade u12 references | PASS |  |
| Upgrade u12 no extra rank | PASS |  |
| Upgrade u13 references | PASS |  |
| Upgrade u13 no extra rank | PASS |  |
| Upgrade u14 references | PASS |  |
| Upgrade u14 no extra rank | PASS |  |
| Upgrade u15 references | PASS |  |
| Upgrade u15 no extra rank | PASS |  |
| Upgrade u16 references | PASS |  |
| Upgrade u16 no extra rank | PASS |  |
| Upgrade u17 references | PASS |  |
| Upgrade u17 no extra rank | PASS |  |
| Upgrade u18 references | PASS |  |
| Upgrade u18 no extra rank | PASS |  |
| Upgrade u19 references | PASS |  |
| Upgrade u19 no extra rank | PASS |  |
| Upgrade u20 references | PASS |  |
| Upgrade u20 no extra rank | PASS |  |
| Upgrade u21 references | PASS |  |
| Upgrade u21 no extra rank | PASS |  |
| Upgrade u22 references | PASS |  |
| Upgrade u22 no extra rank | PASS |  |
| Upgrade u23 references | PASS |  |
| Upgrade u23 no extra rank | PASS |  |
| Upgrade u24 references | PASS |  |
| Upgrade u24 no extra rank | PASS |  |
| u06 secondary effect explicit | PASS |  |
| u17 secondary effect explicit | PASS |  |
| u20 secondary effect explicit | PASS |  |
| Boss asset references | PASS |  |
| Expedition c01_e01 four ordered battles | PASS |  |
| Expedition c01_e01 ownership | PASS |  |
| Expedition c01_e01 prerequisite | PASS |  |
| Expedition c01_e02 four ordered battles | PASS |  |
| Expedition c01_e02 ownership | PASS |  |
| Expedition c01_e02 prerequisite | PASS |  |
| Expedition c01_e03 four ordered battles | PASS |  |
| Expedition c01_e03 ownership | PASS |  |
| Expedition c01_e03 prerequisite | PASS |  |
| Expedition c02_e01 four ordered battles | PASS |  |
| Expedition c02_e01 ownership | PASS |  |
| Expedition c02_e01 prerequisite | PASS |  |
| Expedition c02_e02 four ordered battles | PASS |  |
| Expedition c02_e02 ownership | PASS |  |
| Expedition c02_e02 prerequisite | PASS |  |
| Expedition c02_e03 four ordered battles | PASS |  |
| Expedition c02_e03 ownership | PASS |  |
| Expedition c02_e03 prerequisite | PASS |  |
| Expedition c03_e01 four ordered battles | PASS |  |
| Expedition c03_e01 ownership | PASS |  |
| Expedition c03_e01 prerequisite | PASS |  |
| Expedition c03_e02 four ordered battles | PASS |  |
| Expedition c03_e02 ownership | PASS |  |
| Expedition c03_e02 prerequisite | PASS |  |
| Expedition c03_e03 four ordered battles | PASS |  |
| Expedition c03_e03 ownership | PASS |  |
| Expedition c03_e03 prerequisite | PASS |  |
| Every encounter used once | PASS |  |
| Encounter c01_e01_b01 unit/environment refs | PASS |  |
| Encounter c01_e01_b01 complete spend budget | PASS |  |
| Encounter c01_e01_b01 funding bounds | PASS |  |
| Encounter c01_e01_b01 boss ref | PASS |  |
| Encounter c01_e01_b01 no false simulation PASS | PASS |  |
| Encounter c01_e01_b02 unit/environment refs | PASS |  |
| Encounter c01_e01_b02 complete spend budget | PASS |  |
| Encounter c01_e01_b02 funding bounds | PASS |  |
| Encounter c01_e01_b02 boss ref | PASS |  |
| Encounter c01_e01_b02 no false simulation PASS | PASS |  |
| Encounter c01_e01_b03 unit/environment refs | PASS |  |
| Encounter c01_e01_b03 complete spend budget | PASS |  |
| Encounter c01_e01_b03 funding bounds | PASS |  |
| Encounter c01_e01_b03 boss ref | PASS |  |
| Encounter c01_e01_b03 no false simulation PASS | PASS |  |
| Encounter c01_e01_b04 unit/environment refs | PASS |  |
| Encounter c01_e01_b04 complete spend budget | PASS |  |
| Encounter c01_e01_b04 funding bounds | PASS |  |
| Encounter c01_e01_b04 boss ref | PASS |  |
| Encounter c01_e01_b04 no false simulation PASS | PASS |  |
| Encounter c01_e02_b01 unit/environment refs | PASS |  |
| Encounter c01_e02_b01 complete spend budget | PASS |  |
| Encounter c01_e02_b01 funding bounds | PASS |  |
| Encounter c01_e02_b01 boss ref | PASS |  |
| Encounter c01_e02_b01 no false simulation PASS | PASS |  |
| Encounter c01_e02_b02 unit/environment refs | PASS |  |
| Encounter c01_e02_b02 complete spend budget | PASS |  |
| Encounter c01_e02_b02 funding bounds | PASS |  |
| Encounter c01_e02_b02 boss ref | PASS |  |
| Encounter c01_e02_b02 no false simulation PASS | PASS |  |
| Encounter c01_e02_b03 unit/environment refs | PASS |  |
| Encounter c01_e02_b03 complete spend budget | PASS |  |
| Encounter c01_e02_b03 funding bounds | PASS |  |
| Encounter c01_e02_b03 boss ref | PASS |  |
| Encounter c01_e02_b03 no false simulation PASS | PASS |  |
| Encounter c01_e02_b04 unit/environment refs | PASS |  |
| Encounter c01_e02_b04 complete spend budget | PASS |  |
| Encounter c01_e02_b04 funding bounds | PASS |  |
| Encounter c01_e02_b04 boss ref | PASS |  |
| Encounter c01_e02_b04 no false simulation PASS | PASS |  |
| Encounter c01_e03_b01 unit/environment refs | PASS |  |
| Encounter c01_e03_b01 complete spend budget | PASS |  |
| Encounter c01_e03_b01 funding bounds | PASS |  |
| Encounter c01_e03_b01 boss ref | PASS |  |
| Encounter c01_e03_b01 no false simulation PASS | PASS |  |
| Encounter c01_e03_b02 unit/environment refs | PASS |  |
| Encounter c01_e03_b02 complete spend budget | PASS |  |
| Encounter c01_e03_b02 funding bounds | PASS |  |
| Encounter c01_e03_b02 boss ref | PASS |  |
| Encounter c01_e03_b02 no false simulation PASS | PASS |  |
| Encounter c01_e03_b03 unit/environment refs | PASS |  |
| Encounter c01_e03_b03 complete spend budget | PASS |  |
| Encounter c01_e03_b03 funding bounds | PASS |  |
| Encounter c01_e03_b03 boss ref | PASS |  |
| Encounter c01_e03_b03 no false simulation PASS | PASS |  |
| Encounter c01_e03_b04 unit/environment refs | PASS |  |
| Encounter c01_e03_b04 complete spend budget | PASS |  |
| Encounter c01_e03_b04 funding bounds | PASS |  |
| Encounter c01_e03_b04 boss ref | PASS |  |
| Encounter c01_e03_b04 boss replacement | PASS |  |
| Encounter c01_e03_b04 no false simulation PASS | PASS |  |
| Encounter c02_e01_b01 unit/environment refs | PASS |  |
| Encounter c02_e01_b01 complete spend budget | PASS |  |
| Encounter c02_e01_b01 funding bounds | PASS |  |
| Encounter c02_e01_b01 boss ref | PASS |  |
| Encounter c02_e01_b01 no false simulation PASS | PASS |  |
| Encounter c02_e01_b02 unit/environment refs | PASS |  |
| Encounter c02_e01_b02 complete spend budget | PASS |  |
| Encounter c02_e01_b02 funding bounds | PASS |  |
| Encounter c02_e01_b02 boss ref | PASS |  |
| Encounter c02_e01_b02 no false simulation PASS | PASS |  |
| Encounter c02_e01_b03 unit/environment refs | PASS |  |
| Encounter c02_e01_b03 complete spend budget | PASS |  |
| Encounter c02_e01_b03 funding bounds | PASS |  |
| Encounter c02_e01_b03 boss ref | PASS |  |
| Encounter c02_e01_b03 no false simulation PASS | PASS |  |
| Encounter c02_e01_b04 unit/environment refs | PASS |  |
| Encounter c02_e01_b04 complete spend budget | PASS |  |
| Encounter c02_e01_b04 funding bounds | PASS |  |
| Encounter c02_e01_b04 boss ref | PASS |  |
| Encounter c02_e01_b04 boss replacement | PASS |  |
| Encounter c02_e01_b04 no false simulation PASS | PASS |  |
| Encounter c02_e02_b01 unit/environment refs | PASS |  |
| Encounter c02_e02_b01 complete spend budget | PASS |  |
| Encounter c02_e02_b01 funding bounds | PASS |  |
| Encounter c02_e02_b01 boss ref | PASS |  |
| Encounter c02_e02_b01 no false simulation PASS | PASS |  |
| Encounter c02_e02_b02 unit/environment refs | PASS |  |
| Encounter c02_e02_b02 complete spend budget | PASS |  |
| Encounter c02_e02_b02 funding bounds | PASS |  |
| Encounter c02_e02_b02 boss ref | PASS |  |
| Encounter c02_e02_b02 no false simulation PASS | PASS |  |
| Encounter c02_e02_b03 unit/environment refs | PASS |  |
| Encounter c02_e02_b03 complete spend budget | PASS |  |
| Encounter c02_e02_b03 funding bounds | PASS |  |
| Encounter c02_e02_b03 boss ref | PASS |  |
| Encounter c02_e02_b03 no false simulation PASS | PASS |  |
| Encounter c02_e02_b04 unit/environment refs | PASS |  |
| Encounter c02_e02_b04 complete spend budget | PASS |  |
| Encounter c02_e02_b04 funding bounds | PASS |  |
| Encounter c02_e02_b04 boss ref | PASS |  |
| Encounter c02_e02_b04 no false simulation PASS | PASS |  |
| Encounter c02_e03_b01 unit/environment refs | PASS |  |
| Encounter c02_e03_b01 complete spend budget | PASS |  |
| Encounter c02_e03_b01 funding bounds | PASS |  |
| Encounter c02_e03_b01 boss ref | PASS |  |
| Encounter c02_e03_b01 no false simulation PASS | PASS |  |
| Encounter c02_e03_b02 unit/environment refs | PASS |  |
| Encounter c02_e03_b02 complete spend budget | PASS |  |
| Encounter c02_e03_b02 funding bounds | PASS |  |
| Encounter c02_e03_b02 boss ref | PASS |  |
| Encounter c02_e03_b02 no false simulation PASS | PASS |  |
| Encounter c02_e03_b03 unit/environment refs | PASS |  |
| Encounter c02_e03_b03 complete spend budget | PASS |  |
| Encounter c02_e03_b03 funding bounds | PASS |  |
| Encounter c02_e03_b03 boss ref | PASS |  |
| Encounter c02_e03_b03 no false simulation PASS | PASS |  |
| Encounter c02_e03_b04 unit/environment refs | PASS |  |
| Encounter c02_e03_b04 complete spend budget | PASS |  |
| Encounter c02_e03_b04 funding bounds | PASS |  |
| Encounter c02_e03_b04 boss ref | PASS |  |
| Encounter c02_e03_b04 boss replacement | PASS |  |
| Encounter c02_e03_b04 no false simulation PASS | PASS |  |
| Encounter c03_e01_b01 unit/environment refs | PASS |  |
| Encounter c03_e01_b01 complete spend budget | PASS |  |
| Encounter c03_e01_b01 funding bounds | PASS |  |
| Encounter c03_e01_b01 boss ref | PASS |  |
| Encounter c03_e01_b01 no false simulation PASS | PASS |  |
| Encounter c03_e01_b02 unit/environment refs | PASS |  |
| Encounter c03_e01_b02 complete spend budget | PASS |  |
| Encounter c03_e01_b02 funding bounds | PASS |  |
| Encounter c03_e01_b02 boss ref | PASS |  |
| Encounter c03_e01_b02 no false simulation PASS | PASS |  |
| Encounter c03_e01_b03 unit/environment refs | PASS |  |
| Encounter c03_e01_b03 complete spend budget | PASS |  |
| Encounter c03_e01_b03 funding bounds | PASS |  |
| Encounter c03_e01_b03 boss ref | PASS |  |
| Encounter c03_e01_b03 no false simulation PASS | PASS |  |
| Encounter c03_e01_b04 unit/environment refs | PASS |  |
| Encounter c03_e01_b04 complete spend budget | PASS |  |
| Encounter c03_e01_b04 funding bounds | PASS |  |
| Encounter c03_e01_b04 boss ref | PASS |  |
| Encounter c03_e01_b04 boss replacement | PASS |  |
| Encounter c03_e01_b04 no false simulation PASS | PASS |  |
| Encounter c03_e02_b01 unit/environment refs | PASS |  |
| Encounter c03_e02_b01 complete spend budget | PASS |  |
| Encounter c03_e02_b01 funding bounds | PASS |  |
| Encounter c03_e02_b01 boss ref | PASS |  |
| Encounter c03_e02_b01 no false simulation PASS | PASS |  |
| Encounter c03_e02_b02 unit/environment refs | PASS |  |
| Encounter c03_e02_b02 complete spend budget | PASS |  |
| Encounter c03_e02_b02 funding bounds | PASS |  |
| Encounter c03_e02_b02 boss ref | PASS |  |
| Encounter c03_e02_b02 no false simulation PASS | PASS |  |
| Encounter c03_e02_b03 unit/environment refs | PASS |  |
| Encounter c03_e02_b03 complete spend budget | PASS |  |
| Encounter c03_e02_b03 funding bounds | PASS |  |
| Encounter c03_e02_b03 boss ref | PASS |  |
| Encounter c03_e02_b03 no false simulation PASS | PASS |  |
| Encounter c03_e02_b04 unit/environment refs | PASS |  |
| Encounter c03_e02_b04 complete spend budget | PASS |  |
| Encounter c03_e02_b04 funding bounds | PASS |  |
| Encounter c03_e02_b04 boss ref | PASS |  |
| Encounter c03_e02_b04 boss replacement | PASS |  |
| Encounter c03_e02_b04 no false simulation PASS | PASS |  |
| Encounter c03_e03_b01 unit/environment refs | PASS |  |
| Encounter c03_e03_b01 complete spend budget | PASS |  |
| Encounter c03_e03_b01 funding bounds | PASS |  |
| Encounter c03_e03_b01 boss ref | PASS |  |
| Encounter c03_e03_b01 no false simulation PASS | PASS |  |
| Encounter c03_e03_b02 unit/environment refs | PASS |  |
| Encounter c03_e03_b02 complete spend budget | PASS |  |
| Encounter c03_e03_b02 funding bounds | PASS |  |
| Encounter c03_e03_b02 boss ref | PASS |  |
| Encounter c03_e03_b02 no false simulation PASS | PASS |  |
| Encounter c03_e03_b03 unit/environment refs | PASS |  |
| Encounter c03_e03_b03 complete spend budget | PASS |  |
| Encounter c03_e03_b03 funding bounds | PASS |  |
| Encounter c03_e03_b03 boss ref | PASS |  |
| Encounter c03_e03_b03 no false simulation PASS | PASS |  |
| Encounter c03_e03_b04 unit/environment refs | PASS |  |
| Encounter c03_e03_b04 complete spend budget | PASS |  |
| Encounter c03_e03_b04 funding bounds | PASS |  |
| Encounter c03_e03_b04 boss ref | PASS |  |
| Encounter c03_e03_b04 boss replacement | PASS |  |
| Encounter c03_e03_b04 no false simulation PASS | PASS |  |
| Asset family count: troop_master | PASS | 6 / 6 |
| Asset family count: derived_boss | PASS | 2 / 2 |
| Asset family count: environment | PASS | 3 / 3 |
| Asset family count: base | PASS | 2 / 2 |
| Asset family count: unit_portrait | PASS | 6 / 6 |
| Asset family count: animation_binding | PASS | 36 / 36 |
| Asset family count: upgrade_icon | PASS | 24 / 24 |
| Asset family count: ui_view | PASS | 6 / 6 |
| Asset family count: vfx_prefab | PASS | 12 / 12 |
| Asset family count: sound_effect | PASS | 25 / 25 |
| Asset family count: music_loop | PASS | 2 / 2 |
| Asset family count: audio_sting | PASS | 3 / 3 |
| Asset family count: earned_banner | PASS | 3 / 3 |
| Asset family count: paid_cosmetic_family | PASS | 1 / 1 |
| Asset unit_militia honest pending state | PASS |  |
| Asset unit_militia dependencies | PASS |  |
| Asset portrait_militia honest pending state | PASS |  |
| Asset portrait_militia dependencies | PASS |  |
| Asset anim_militia_idle honest pending state | PASS |  |
| Asset anim_militia_idle dependencies | PASS |  |
| Asset anim_militia_move honest pending state | PASS |  |
| Asset anim_militia_move dependencies | PASS |  |
| Asset anim_militia_attack honest pending state | PASS |  |
| Asset anim_militia_attack dependencies | PASS |  |
| Asset anim_militia_hit honest pending state | PASS |  |
| Asset anim_militia_hit dependencies | PASS |  |
| Asset anim_militia_death honest pending state | PASS |  |
| Asset anim_militia_death dependencies | PASS |  |
| Asset anim_militia_victory honest pending state | PASS |  |
| Asset anim_militia_victory dependencies | PASS |  |
| Asset unit_shieldguard honest pending state | PASS |  |
| Asset unit_shieldguard dependencies | PASS |  |
| Asset portrait_shieldguard honest pending state | PASS |  |
| Asset portrait_shieldguard dependencies | PASS |  |
| Asset anim_shieldguard_idle honest pending state | PASS |  |
| Asset anim_shieldguard_idle dependencies | PASS |  |
| Asset anim_shieldguard_move honest pending state | PASS |  |
| Asset anim_shieldguard_move dependencies | PASS |  |
| Asset anim_shieldguard_attack honest pending state | PASS |  |
| Asset anim_shieldguard_attack dependencies | PASS |  |
| Asset anim_shieldguard_hit honest pending state | PASS |  |
| Asset anim_shieldguard_hit dependencies | PASS |  |
| Asset anim_shieldguard_death honest pending state | PASS |  |
| Asset anim_shieldguard_death dependencies | PASS |  |
| Asset anim_shieldguard_victory honest pending state | PASS |  |
| Asset anim_shieldguard_victory dependencies | PASS |  |
| Asset unit_crossbowman honest pending state | PASS |  |
| Asset unit_crossbowman dependencies | PASS |  |
| Asset portrait_crossbowman honest pending state | PASS |  |
| Asset portrait_crossbowman dependencies | PASS |  |
| Asset anim_crossbowman_idle honest pending state | PASS |  |
| Asset anim_crossbowman_idle dependencies | PASS |  |
| Asset anim_crossbowman_move honest pending state | PASS |  |
| Asset anim_crossbowman_move dependencies | PASS |  |
| Asset anim_crossbowman_attack honest pending state | PASS |  |
| Asset anim_crossbowman_attack dependencies | PASS |  |
| Asset anim_crossbowman_hit honest pending state | PASS |  |
| Asset anim_crossbowman_hit dependencies | PASS |  |
| Asset anim_crossbowman_death honest pending state | PASS |  |
| Asset anim_crossbowman_death dependencies | PASS |  |
| Asset anim_crossbowman_victory honest pending state | PASS |  |
| Asset anim_crossbowman_victory dependencies | PASS |  |
| Asset unit_grenadier honest pending state | PASS |  |
| Asset unit_grenadier dependencies | PASS |  |
| Asset portrait_grenadier honest pending state | PASS |  |
| Asset portrait_grenadier dependencies | PASS |  |
| Asset anim_grenadier_idle honest pending state | PASS |  |
| Asset anim_grenadier_idle dependencies | PASS |  |
| Asset anim_grenadier_move honest pending state | PASS |  |
| Asset anim_grenadier_move dependencies | PASS |  |
| Asset anim_grenadier_attack honest pending state | PASS |  |
| Asset anim_grenadier_attack dependencies | PASS |  |
| Asset anim_grenadier_hit honest pending state | PASS |  |
| Asset anim_grenadier_hit dependencies | PASS |  |
| Asset anim_grenadier_death honest pending state | PASS |  |
| Asset anim_grenadier_death dependencies | PASS |  |
| Asset anim_grenadier_victory honest pending state | PASS |  |
| Asset anim_grenadier_victory dependencies | PASS |  |
| Asset unit_brute honest pending state | PASS |  |
| Asset unit_brute dependencies | PASS |  |
| Asset portrait_brute honest pending state | PASS |  |
| Asset portrait_brute dependencies | PASS |  |
| Asset anim_brute_idle honest pending state | PASS |  |
| Asset anim_brute_idle dependencies | PASS |  |
| Asset anim_brute_move honest pending state | PASS |  |
| Asset anim_brute_move dependencies | PASS |  |
| Asset anim_brute_attack honest pending state | PASS |  |
| Asset anim_brute_attack dependencies | PASS |  |
| Asset anim_brute_hit honest pending state | PASS |  |
| Asset anim_brute_hit dependencies | PASS |  |
| Asset anim_brute_death honest pending state | PASS |  |
| Asset anim_brute_death dependencies | PASS |  |
| Asset anim_brute_victory honest pending state | PASS |  |
| Asset anim_brute_victory dependencies | PASS |  |
| Asset unit_ram honest pending state | PASS |  |
| Asset unit_ram dependencies | PASS |  |
| Asset portrait_ram honest pending state | PASS |  |
| Asset portrait_ram dependencies | PASS |  |
| Asset anim_ram_idle honest pending state | PASS |  |
| Asset anim_ram_idle dependencies | PASS |  |
| Asset anim_ram_move honest pending state | PASS |  |
| Asset anim_ram_move dependencies | PASS |  |
| Asset anim_ram_attack honest pending state | PASS |  |
| Asset anim_ram_attack dependencies | PASS |  |
| Asset anim_ram_hit honest pending state | PASS |  |
| Asset anim_ram_hit dependencies | PASS |  |
| Asset anim_ram_death honest pending state | PASS |  |
| Asset anim_ram_death dependencies | PASS |  |
| Asset anim_ram_victory honest pending state | PASS |  |
| Asset anim_ram_victory dependencies | PASS |  |
| Asset boss_bulwark honest pending state | PASS |  |
| Asset boss_bulwark dependencies | PASS |  |
| Asset boss_powder honest pending state | PASS |  |
| Asset boss_powder dependencies | PASS |  |
| Asset env_fields honest pending state | PASS |  |
| Asset env_fields dependencies | PASS |  |
| Asset env_timber honest pending state | PASS |  |
| Asset env_timber dependencies | PASS |  |
| Asset env_keep honest pending state | PASS |  |
| Asset env_keep dependencies | PASS |  |
| Asset base_player honest pending state | PASS |  |
| Asset base_player dependencies | PASS |  |
| Asset base_enemy honest pending state | PASS |  |
| Asset base_enemy dependencies | PASS |  |
| Asset icon_u01 honest pending state | PASS |  |
| Asset icon_u01 dependencies | PASS |  |
| Asset icon_u02 honest pending state | PASS |  |
| Asset icon_u02 dependencies | PASS |  |
| Asset icon_u03 honest pending state | PASS |  |
| Asset icon_u03 dependencies | PASS |  |
| Asset icon_u04 honest pending state | PASS |  |
| Asset icon_u04 dependencies | PASS |  |
| Asset icon_u05 honest pending state | PASS |  |
| Asset icon_u05 dependencies | PASS |  |
| Asset icon_u06 honest pending state | PASS |  |
| Asset icon_u06 dependencies | PASS |  |
| Asset icon_u07 honest pending state | PASS |  |
| Asset icon_u07 dependencies | PASS |  |
| Asset icon_u08 honest pending state | PASS |  |
| Asset icon_u08 dependencies | PASS |  |
| Asset icon_u09 honest pending state | PASS |  |
| Asset icon_u09 dependencies | PASS |  |
| Asset icon_u10 honest pending state | PASS |  |
| Asset icon_u10 dependencies | PASS |  |
| Asset icon_u11 honest pending state | PASS |  |
| Asset icon_u11 dependencies | PASS |  |
| Asset icon_u12 honest pending state | PASS |  |
| Asset icon_u12 dependencies | PASS |  |
| Asset icon_u13 honest pending state | PASS |  |
| Asset icon_u13 dependencies | PASS |  |
| Asset icon_u14 honest pending state | PASS |  |
| Asset icon_u14 dependencies | PASS |  |
| Asset icon_u15 honest pending state | PASS |  |
| Asset icon_u15 dependencies | PASS |  |
| Asset icon_u16 honest pending state | PASS |  |
| Asset icon_u16 dependencies | PASS |  |
| Asset icon_u17 honest pending state | PASS |  |
| Asset icon_u17 dependencies | PASS |  |
| Asset icon_u18 honest pending state | PASS |  |
| Asset icon_u18 dependencies | PASS |  |
| Asset icon_u19 honest pending state | PASS |  |
| Asset icon_u19 dependencies | PASS |  |
| Asset icon_u20 honest pending state | PASS |  |
| Asset icon_u20 dependencies | PASS |  |
| Asset icon_u21 honest pending state | PASS |  |
| Asset icon_u21 dependencies | PASS |  |
| Asset icon_u22 honest pending state | PASS |  |
| Asset icon_u22 dependencies | PASS |  |
| Asset icon_u23 honest pending state | PASS |  |
| Asset icon_u23 dependencies | PASS |  |
| Asset icon_u24 honest pending state | PASS |  |
| Asset icon_u24 dependencies | PASS |  |
| Asset ui_home_campaign honest pending state | PASS |  |
| Asset ui_home_campaign dependencies | PASS |  |
| Asset ui_army honest pending state | PASS |  |
| Asset ui_army dependencies | PASS |  |
| Asset ui_battle honest pending state | PASS |  |
| Asset ui_battle dependencies | PASS |  |
| Asset ui_draft honest pending state | PASS |  |
| Asset ui_draft dependencies | PASS |  |
| Asset ui_results honest pending state | PASS |  |
| Asset ui_results dependencies | PASS |  |
| Asset ui_shop honest pending state | PASS |  |
| Asset ui_shop dependencies | PASS |  |
| Asset ui_icon_medal honest pending state | PASS |  |
| Asset ui_icon_medal dependencies | PASS |  |
| Asset ui_icon_supply honest pending state | PASS |  |
| Asset ui_icon_supply dependencies | PASS |  |
| Asset ui_icon_health honest pending state | PASS |  |
| Asset ui_icon_health dependencies | PASS |  |
| Asset ui_icon_rally honest pending state | PASS |  |
| Asset ui_icon_rally dependencies | PASS |  |
| Asset ui_icon_pause honest pending state | PASS |  |
| Asset ui_icon_pause dependencies | PASS |  |
| Asset ui_icon_close honest pending state | PASS |  |
| Asset ui_icon_close dependencies | PASS |  |
| Asset ui_icon_back honest pending state | PASS |  |
| Asset ui_icon_back dependencies | PASS |  |
| Asset ui_icon_lock honest pending state | PASS |  |
| Asset ui_icon_lock dependencies | PASS |  |
| Asset ui_icon_check honest pending state | PASS |  |
| Asset ui_icon_check dependencies | PASS |  |
| Asset ui_icon_retry honest pending state | PASS |  |
| Asset ui_icon_retry dependencies | PASS |  |
| Asset ui_icon_audio honest pending state | PASS |  |
| Asset ui_icon_audio dependencies | PASS |  |
| Asset ui_icon_privacy honest pending state | PASS |  |
| Asset ui_icon_privacy dependencies | PASS |  |
| Asset music_menu honest pending state | PASS |  |
| Asset music_menu dependencies | PASS |  |
| Asset music_battle honest pending state | PASS |  |
| Asset music_battle dependencies | PASS |  |
| Asset banner_oak honest pending state | PASS |  |
| Asset banner_oak dependencies | PASS |  |
| Asset banner_barrel honest pending state | PASS |  |
| Asset banner_barrel dependencies | PASS |  |
| Asset banner_iron honest pending state | PASS |  |
| Asset banner_iron dependencies | PASS |  |
| Asset cosmetic_paid_set honest pending state | PASS |  |
| Asset cosmetic_paid_set dependencies | PASS |  |
| Asset store_app_icon honest pending state | PASS |  |
| Asset store_app_icon dependencies | PASS |  |
| Asset store_feature_graphic honest pending state | PASS |  |
| Asset store_feature_graphic dependencies | PASS |  |
| Asset store_screenshot_set honest pending state | PASS |  |
| Asset store_screenshot_set dependencies | PASS |  |
| Asset store_gameplay_trailer honest pending state | PASS |  |
| Asset store_gameplay_trailer dependencies | PASS |  |
| Asset store_store_copy honest pending state | PASS |  |
| Asset store_store_copy dependencies | PASS |  |
| Asset vfx_deployment_dust honest pending state | PASS |  |
| Asset vfx_deployment_dust dependencies | PASS |  |
| Asset vfx_melee_slash honest pending state | PASS |  |
| Asset vfx_melee_slash dependencies | PASS |  |
| Asset vfx_light_hit honest pending state | PASS |  |
| Asset vfx_light_hit dependencies | PASS |  |
| Asset vfx_shield_block honest pending state | PASS |  |
| Asset vfx_shield_block dependencies | PASS |  |
| Asset vfx_bolt_trail_impact honest pending state | PASS |  |
| Asset vfx_bolt_trail_impact dependencies | PASS |  |
| Asset vfx_grenade_explosion honest pending state | PASS |  |
| Asset vfx_grenade_explosion dependencies | PASS |  |
| Asset vfx_spawn_barrier honest pending state | PASS |  |
| Asset vfx_spawn_barrier dependencies | PASS |  |
| Asset vfx_rally_aura honest pending state | PASS |  |
| Asset vfx_rally_aura dependencies | PASS |  |
| Asset vfx_hit_flash honest pending state | PASS |  |
| Asset vfx_hit_flash dependencies | PASS |  |
| Asset vfx_death_puff honest pending state | PASS |  |
| Asset vfx_death_puff dependencies | PASS |  |
| Asset vfx_medal_reward honest pending state | PASS |  |
| Asset vfx_medal_reward dependencies | PASS |  |
| Asset vfx_fortress_destruction honest pending state | PASS |  |
| Asset vfx_fortress_destruction dependencies | PASS |  |
| Asset sfx_ui_tap honest pending state | PASS |  |
| Asset sfx_ui_tap dependencies | PASS |  |
| Asset sfx_ui_confirm honest pending state | PASS |  |
| Asset sfx_ui_confirm dependencies | PASS |  |
| Asset sfx_ui_cancel honest pending state | PASS |  |
| Asset sfx_ui_cancel dependencies | PASS |  |
| Asset sfx_ui_error honest pending state | PASS |  |
| Asset sfx_ui_error dependencies | PASS |  |
| Asset sfx_deploy honest pending state | PASS |  |
| Asset sfx_deploy dependencies | PASS |  |
| Asset sfx_troop_unlock honest pending state | PASS |  |
| Asset sfx_troop_unlock dependencies | PASS |  |
| Asset sfx_draft_choose honest pending state | PASS |  |
| Asset sfx_draft_choose dependencies | PASS |  |
| Asset sfx_medal_receipt honest pending state | PASS |  |
| Asset sfx_medal_receipt dependencies | PASS |  |
| Asset sfx_light_swing honest pending state | PASS |  |
| Asset sfx_light_swing dependencies | PASS |  |
| Asset sfx_club_swing honest pending state | PASS |  |
| Asset sfx_club_swing dependencies | PASS |  |
| Asset sfx_light_impact honest pending state | PASS |  |
| Asset sfx_light_impact dependencies | PASS |  |
| Asset sfx_shield_impact honest pending state | PASS |  |
| Asset sfx_shield_impact dependencies | PASS |  |
| Asset sfx_heavy_impact honest pending state | PASS |  |
| Asset sfx_heavy_impact dependencies | PASS |  |
| Asset sfx_crossbow_fire honest pending state | PASS |  |
| Asset sfx_crossbow_fire dependencies | PASS |  |
| Asset sfx_bolt_impact honest pending state | PASS |  |
| Asset sfx_bolt_impact dependencies | PASS |  |
| Asset sfx_grenade_release honest pending state | PASS |  |
| Asset sfx_grenade_release dependencies | PASS |  |
| Asset sfx_explosion honest pending state | PASS |  |
| Asset sfx_explosion dependencies | PASS |  |
| Asset sfx_ram_roll honest pending state | PASS |  |
| Asset sfx_ram_roll dependencies | PASS |  |
| Asset sfx_ram_impact honest pending state | PASS |  |
| Asset sfx_ram_impact dependencies | PASS |  |
| Asset sfx_soft_death honest pending state | PASS |  |
| Asset sfx_soft_death dependencies | PASS |  |
| Asset sfx_heavy_death honest pending state | PASS |  |
| Asset sfx_heavy_death dependencies | PASS |  |
| Asset sfx_rally honest pending state | PASS |  |
| Asset sfx_rally dependencies | PASS |  |
| Asset sfx_base_damage honest pending state | PASS |  |
| Asset sfx_base_damage dependencies | PASS |  |
| Asset sfx_base_destruction honest pending state | PASS |  |
| Asset sfx_base_destruction dependencies | PASS |  |
| Asset sfx_overtime_warning honest pending state | PASS |  |
| Asset sfx_overtime_warning dependencies | PASS |  |
| Asset sting_victory honest pending state | PASS |  |
| Asset sting_victory dependencies | PASS |  |
| Asset sting_defeat honest pending state | PASS |  |
| Asset sting_defeat dependencies | PASS |  |
| Asset sting_expedition_completion honest pending state | PASS |  |
| Asset sting_expedition_completion dependencies | PASS |  |
| Troop unlock brute | PASS |  |
| Troop unlock ram | PASS |  |
| Banner unlock banner_oak | PASS |  |
| Banner unlock banner_barrel | PASS |  |
| Banner unlock banner_iron | PASS |  |
| Finite Medal sinks total 660 | PASS |  |
| All planned game QA remains NOT_RUN | PASS |  |
| All gates remain NOT_STARTED | PASS |  |
| QA gate QA-001 | PASS |  |
| QA gate QA-002 | PASS |  |
| QA gate QA-003 | PASS |  |
| QA gate QA-004 | PASS |  |
| QA gate QA-005 | PASS |  |
| QA gate QA-006 | PASS |  |
| QA gate QA-007 | PASS |  |
| QA gate QA-008 | PASS |  |
| QA gate QA-009 | PASS |  |
| QA gate QA-010 | PASS |  |
| QA gate QA-011 | PASS |  |
| QA gate QA-012 | PASS |  |
| QA gate QA-013 | PASS |  |
| QA gate QA-014 | PASS |  |
| QA gate QA-015 | PASS |  |
| QA gate QA-016 | PASS |  |
| QA gate QA-017 | PASS |  |
| QA gate QA-018 | PASS |  |
| QA gate QA-019 | PASS |  |
| QA gate QA-020 | PASS |  |
| QA gate QA-021 | PASS |  |
| QA gate QA-022 | PASS |  |
| QA gate QA-023 | PASS |  |
| QA gate QA-024 | PASS |  |
| QA gate QA-025 | PASS |  |
| QA gate QA-026 | PASS |  |
| QA gate QA-027 | PASS |  |
| QA gate QA-028 | PASS |  |
| QA gate QA-029 | PASS |  |
| QA gate QA-030 | PASS |  |
| QA gate QA-031 | PASS |  |
| QA gate QA-032 | PASS |  |
| QA gate QA-033 | PASS |  |
| QA gate QA-034 | PASS |  |
| QA gate QA-035 | PASS |  |
| QA gate QA-036 | PASS |  |
| QA gate QA-037 | PASS |  |
| QA gate QA-038 | PASS |  |
| QA gate QA-039 | PASS |  |
| QA gate QA-040 | PASS |  |
| QA gate QA-041 | PASS |  |
| QA gate QA-042 | PASS |  |
| QA gate QA-043 | PASS |  |
| QA gate QA-044 | PASS |  |
| QA gate QA-045 | PASS |  |
| QA gate QA-046 | PASS |  |
| QA gate QA-047 | PASS |  |
| QA gate QA-048 | PASS |  |
| QA gate QA-049 | PASS |  |
| QA gate QA-050 | PASS |  |
| QA gate QA-051 | PASS |  |
| QA gate QA-052 | PASS |  |
| QA gate QA-053 | PASS |  |
| QA gate QA-054 | PASS |  |
| QA gate QA-055 | PASS |  |
| QA gate QA-056 | PASS |  |
| QA gate QA-057 | PASS |  |
| QA gate QA-058 | PASS |  |
| QA gate QA-059 | PASS |  |
| QA gate QA-060 | PASS |  |
| QA gate QA-061 | PASS |  |
| QA gate QA-062 | PASS |  |
| QA gate QA-063 | PASS |  |
| QA gate QA-064 | PASS |  |
| QA gate QA-065 | PASS |  |
| QA gate QA-066 | PASS |  |
| QA gate QA-067 | PASS |  |
| QA gate QA-068 | PASS |  |
| QA gate QA-069 | PASS |  |
| QA gate QA-070 | PASS |  |
| QA gate QA-071 | PASS |  |
| QA gate QA-072 | PASS |  |
| QA gate QA-073 | PASS |  |
| QA gate QA-074 | PASS |  |
| QA gate QA-075 | PASS |  |
| QA gate QA-076 | PASS |  |
| QA gate QA-077 | PASS |  |
| QA gate QA-078 | PASS |  |
| QA gate QA-079 | PASS |  |
| QA gate QA-080 | PASS |  |
| QA gate QA-081 | PASS |  |
| QA gate QA-082 | PASS |  |
| QA gate QA-083 | PASS |  |
| QA gate QA-084 | PASS |  |
| QA gate QA-085 | PASS |  |
| QA gate QA-086 | PASS |  |
| QA gate QA-087 | PASS |  |
| QA gate QA-088 | PASS |  |
| QA gate QA-089 | PASS |  |
| QA gate QA-090 | PASS |  |
| QA gate QA-091 | PASS |  |
| QA gate QA-092 | PASS |  |
| QA gate QA-093 | PASS |  |
| Gate prerequisites G0 | PASS |  |
| Gate prerequisites G1 | PASS |  |
| Gate prerequisites G2 | PASS |  |
| Gate prerequisites G3 | PASS |  |
| Gate prerequisites G4 | PASS |  |
| Gate prerequisites G5 | PASS |  |
| Gate prerequisites G6 | PASS |  |
| Gate prerequisites G7 | PASS |  |
| Gate prerequisites G8 | PASS |  |
| Gate prerequisites G9 | PASS |  |
| Gate prerequisites G10 | PASS |  |
| Animation proof follows toolchain | PASS |  |
| Event names unique | PASS |  |
| Event syntax ev01 | PASS |  |
| Event syntax ev02 | PASS |  |
| Event syntax ev03 | PASS |  |
| Event syntax ev04 | PASS |  |
| Event syntax ev05 | PASS |  |
| Event syntax ev06 | PASS |  |
| Event syntax ev07 | PASS |  |
| Event syntax ev08 | PASS |  |
| Event syntax ev09 | PASS |  |
| Event syntax ev10 | PASS |  |
| Event syntax ev11 | PASS |  |
| Event syntax ev12 | PASS |  |
| Event syntax ev13 | PASS |  |
| Event syntax ev14 | PASS |  |
| Event syntax ev15 | PASS |  |
| Event syntax ev16 | PASS |  |
| Event syntax ev17 | PASS |  |
| Event syntax ev18 | PASS |  |
| Event syntax ev19 | PASS |  |
| Event syntax ev20 | PASS |  |
| Event syntax ev21 | PASS |  |
| Event syntax ev22 | PASS |  |
| Event syntax ev23 | PASS |  |
| Event syntax ev24 | PASS |  |
| Event syntax ev25 | PASS |  |
| Event syntax ev26 | PASS |  |
| Event syntax ev27 | PASS |  |
| Event syntax ev28 | PASS |  |
| Event syntax ev29 | PASS |  |
| Event syntax ev30 | PASS |  |
| Event syntax ev31 | PASS |  |
| Event syntax ev32 | PASS |  |
| Event syntax ev33 | PASS |  |
| Event syntax ev34 | PASS |  |
| Event syntax ev35 | PASS |  |
| No unresolved source template | PASS |  |
| All manual source IDs resolve | PASS |  |
| No invented runtime/approval PASS in status | PASS |  |
