#!/usr/bin/env python3
"""Validate planning-file structure. Does NOT simulate or build the game.
Run: python validate_plan.py
Requires Python 3.10+, standard library only.
"""
from __future__ import annotations
import collections
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks: list[tuple[str, bool, str]] = []
def check(label: str, condition: bool, detail: str = '') -> None:
    checks.append((label, bool(condition), detail))
def read(name: str):
    return json.loads((ROOT/'data'/name).read_text(encoding='utf-8'))
def unique(rows, name):
    keys=[r['id'] for r in rows]
    check(f'{name}: unique IDs',len(keys)==len(set(keys)))
    return {r['id']:r for r in rows}

def main() -> int:
    try:
        all_json={f.name:json.loads(f.read_text(encoding='utf-8')) for f in sorted((ROOT/'data').glob('*.json'))}
        check('All planning registries parse as JSON',True,f'{len(all_json)} registries')
        rules=read('game_rules.json')
        U=unique(read('units.json'),'Units'); UP=unique(read('upgrades.json'),'Upgrades')
        E=unique(read('encounters.json'),'Encounters'); X=unique(read('expeditions.json'),'Expeditions')
        B=unique(read('boss_variants.json'),'Bosses'); A=unique(read('assets.json'),'Assets')
        G=unique(read('build_gates.json'),'Gates'); T=unique(read('qa_cases.json'),'QA')
        EV=unique(read('analytics_events.json'),'Events'); S=unique(read('sources.json'),'Sources')
        P=unique(read('products.json'),'Products'); D=unique(read('open_decisions.json'),'Decisions')
        econ=read('economy.json'); rig=read('animation_contract.json')
        for name,got,want in [('troops',len(U),6),('upgrades',len(UP),24),('encounters',len(E),36),('expeditions',len(X),9),('bosses',len(B),2),('purchases',len(P),2),('custom_events',len(EV),35),('gates',len(G),11)]:
            check(f'Count: {name}',got==want,f'{got} / {want}')
        check('No source approval or production authorization asserted',rules['human_approved'] is False and rules['production_authorized'] is False)
        check('Balance explicitly untested',rules['balance_status']=='UNSIMULATED_STARTING_VALUES')
        check('No accounts or cloud progression silently added',rules['player_accounts'] is False and rules['cloud_progression'] is False)
        check('No forced ads',rules['scope']['forced_ads']==0)
        check('Single currency; no premium currency',econ['currency']=='medals' and econ['premium_currency'] is False)
        check('Only four initial troops',sum(u['unlocked_initially'] for u in U.values())==4)
        check('Six behavior upgrades',sum(u['kind']=='behavior' for u in UP.values())==6)
        check('Six general upgrades',sum(u['requires_equipped_unit'] is None for u in UP.values())==6)
        for u in U.values():
            check(f"Unit {u['id']} asset/rig",u['master_asset_id'] in A and u['rig'] in rig['rigs'])
            check(f"Unit {u['id']} valid numeric seeds",all(u[k]>0 for k in ['supply_cost','hp','damage','attack_period_s','range_m','move_speed_m_s','base_damage']))
            check(f"Unit {u['id']} windup",0<=u['windup_s']<u['attack_period_s'])
        for u in UP.values():
            check(f"Upgrade {u['id']} references",u['icon_asset_id'] in A and (u['requires_equipped_unit'] is None or u['requires_equipped_unit'] in U))
            check(f"Upgrade {u['id']} no extra rank",u['max_rank']==1)
        for id,key in [('u06','movement_add_pct'),('u17','supply_cost_add_pct'),('u20','starting_supply_add')]:
            check(f'{id} secondary effect explicit',key in UP[id]['additional_rules'])
        check('Boss asset references',all(b['asset_id'] in A and b['base_unit'] in U for b in B.values()))
        used=[]
        for x in X.values():
            ids=x['encounter_ids'];used.extend(ids)
            check(f"Expedition {x['id']} four ordered battles",len(ids)==4 and all(i in E for i in ids) and [E[i]['battle_index'] for i in ids]==[1,2,3,4])
            check(f"Expedition {x['id']} ownership",all(E[i]['expedition_id']==x['id'] for i in ids))
            check(f"Expedition {x['id']} prerequisite",x['unlock_after_expedition'] is None or x['unlock_after_expedition'] in X)
        check('Every encounter used once',len(used)==len(set(used))==len(E) and set(used)==set(E))
        for e in E.values():
            q=e['enemy_spawn_queue']
            check(f"Encounter {e['id']} unit/environment refs",len(q)>0 and all(i in U for i in q) and e['environment_asset_id'] in A)
            check(f"Encounter {e['id']} complete spend budget",sum(U[i]['supply_cost'] for i in q)==e['enemy_total_supply_budget'])
            check(f"Encounter {e['id']} funding bounds",0<=e['enemy_supply_start']<=e['enemy_supply_cap'] and e['enemy_supply_rate_per_s']>0 and max(U[i]['supply_cost'] for i in q)<=e['enemy_supply_cap'])
            check(f"Encounter {e['id']} boss ref",e['boss_variant'] is None or e['boss_variant'] in B)
            if e['boss_variant']:
                base=B[e['boss_variant']]['base_unit']
                check(f"Encounter {e['id']} boss replacement",base in q and e['boss_queue_replacement']=='first '+base and e['battle_index']==4)
            check(f"Encounter {e['id']} no false simulation PASS",e['status']=='CONFIGURED_NOT_SIMULATED')
        cat=collections.Counter(a['category'] for a in A.values())
        for key,want in [('troop_master',6),('derived_boss',2),('environment',3),('base',2),('unit_portrait',6),('animation_binding',36),('upgrade_icon',24),('ui_view',6),('vfx_prefab',12),('sound_effect',25),('music_loop',2),('audio_sting',3),('earned_banner',3),('paid_cosmetic_family',1)]:
            check(f'Asset family count: {key}',cat[key]==want,f'{cat[key]} / {want}')
        for a in A.values():
            check(f"Asset {a['id']} honest pending state",a['status']=='PLANNED_NOT_GENERATED' and a['source_path'] is None and a['sha256'] is None and a['approval']=='PENDING')
            check(f"Asset {a['id']} dependencies",all(d in A for d in a.get('depends_on',[])))
        for unlock in econ['troop_unlocks']:check('Troop unlock '+unlock,unlock in U)
        for b in econ['cosmetic_banners']:check('Banner unlock '+b['id'],b['id'] in A)
        check('Finite Medal sinks total 660',sum(econ['troop_unlocks'].values())+sum(b['cost_medals'] for b in econ['cosmetic_banners'])==660)
        check('All planned game QA remains NOT_RUN',all(t['status']=='NOT_RUN' and t['evidence'] is None for t in T.values()))
        check('All gates remain NOT_STARTED',all(g['status']=='NOT_STARTED' and g['evidence'] is None for g in G.values()))
        for t in T.values():check('QA gate '+t['id'],t['gate'] in G)
        for g in G.values():check('Gate prerequisites '+g['id'],all(d in G and int(d[1:])<int(g['id'][1:]) for d in g['depends_on']))
        check('Animation proof follows toolchain',G['G2']['depends_on']==['G1'])
        names=[e['name'] for e in EV.values()]
        check('Event names unique',len(names)==len(set(names)))
        for ev in EV.values():
            fields=ev['parameters']+ev['common_envelope']
            check('Event syntax '+ev['id'],bool(re.fullmatch('[a-zA-Z][a-zA-Z0-9_]{0,39}',ev['name'])) and len(set(fields))==len(fields) and len(fields)<=25)
        manual=(ROOT/'MASTER_PLAN.md').read_text(encoding='utf-8')
        check('No unresolved source template','{{SOURCE_LIST}}' not in manual)
        mentioned=set(re.findall(r'\bS\d\d\b',manual))
        check('All manual source IDs resolve',mentioned<=set(S))
        check('No invented runtime/approval PASS in status',manual.startswith('# One Lane War') and 'not human-approved' in manual and 'not a Unity implementation' in manual)
    except Exception as e:
        check('Validator execution',False,f'{type(e).__name__}: {e}')
    failed=[c for c in checks if not c[1]]
    lines=['# Structural validation — planning files only','',f"**Result: {'PASS' if not failed else 'FAIL'}**",f'Checks evaluated: {len(checks)}. Failed: {len(failed)}.','',
      'This script checks JSON parsing, counts, identities, cross-references, queue budget arithmetic, scope flags, asset/QA pending status, and gate ordering. It does not run Unity, simulate combat, render assets, validate licences, test services/devices, or establish commercial performance.','',
      'All game QA cases remain **NOT_RUN**. All production gates remain **NOT_STARTED**.','', '| Check | Result | Detail |','|---|---|---|']
    lines += [f"| {label} | {'PASS' if ok else 'FAIL'} | {detail.replace('|','/')} |" for label,ok,detail in checks]
    (ROOT/'evidence').mkdir(exist_ok=True)
    (ROOT/'evidence'/'STRUCTURAL_VALIDATION.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(f"{'PASS' if not failed else 'FAIL'}: {len(checks)} structural checks; {len(failed)} failed. No gameplay or device tests run.")
    for c in failed:print(c)
    return 1 if failed else 0
if __name__=='__main__':sys.exit(main())
