# One Lane War — Planning Baseline v0.1.0

Prepared 27 September 2026. **PROPOSED / NO PRODUCTION AUTHORIZATION.**

## Read first

Open `MASTER_PLAN.html` for the complete illustrated-by-tables, searchable-in-browser planning manual. `MASTER_PLAN.md` is the same content in editable text. The package contains no generated art, audio, Unity project, Android build, live backend, or live dashboard.

The original scope is retained: Android, Unity, one landscape lane, six troops/four equipped, four-battle expeditions, 24 upgrades, nine expeditions/36 encounter configurations, two derived bosses, one earned currency, two rewarded placements, and two nonconsumable products. Higgsfield provides visual sources, Suno music, ElevenLabs SFX. Proposed animation is Unity-native 2D cutout rigs, not generated video playback.

## Contents

- Complete master manual covering design, mechanics, content, animation, visuals/audio/VFX, UI, saves, purchases/ads, privacy, analytics, QA, builds, publishing, acquisition, costs, maintenance and retirement.
- Fifteen JSON registries: game rules, six troops, 24 upgrades, 36 encounters, nine expeditions, two boss variants, economy, products, 35 analytics events, 148 asset-family/state/UI/marketing records, animation contract, 93 planned QA checks, 11 build gates, unresolved decisions, and 30 primary sources.
- `validate_plan.py` and `evidence/STRUCTURAL_VALIDATION.md`: actual structural validation of these planning files.
- `START_CODEX.md`: read-only intake instructions; not an instruction to start implementation.
- `MANIFEST.json`: hashes for the delivered files, excluding the manifest itself.

## Validation boundary

The planning validator passed 775 structural checks: IDs, counts, references, queue-cost arithmetic, status flags and gate order. **Combat was not simulated. No Unity/device/service tests were run.** All 93 QA cases remain NOT_RUN. All 11 production gates remain NOT_STARTED. All asset records remain PLANNED_NOT_GENERATED. No human approval or spending authorization is implied.

Gameplay statistics, progression amounts, prices, retention thresholds and engineering budgets are test candidates. Provider/platform facts are sourced and dated; recheck changing requirements at toolchain pinning and submission. Specific commercial licences must be evidenced for the actual account, subscription, source/model and output dates.

## Repeat the structural checks

With Python 3.10 or later, run from this folder:

```text
python validate_plan.py
```

This rewrites the structural report with the same deterministic content if unchanged. The standard library is sufficient. The validator is not a reference combat engine and does not validate the semantic balance of the game.

## Authority and safe handoff

Resolve the open decisions and approve a frozen source before implementation. A later source freeze must record a new version, exact manifest hash and explicit owner approval. Do not treat this draft as the production authority for Roman Legacy, BBGL or Reactorfall. Do not copy another game's data or assets into this project. Generation spending, accounts/credentials, signatures, entitlements and publication remain separately authorized actions.
